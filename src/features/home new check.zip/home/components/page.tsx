"use client";

/**
 * page.tsx — Demo page that wires the new refactored Header.tsx to the body
 * content from the HTML prototype. Body content is intentionally kept as-is
 * (the hero `<main>` block) so we can verify navbar ↔ body interaction and
 * mobile responsiveness.
 */

import Header from "./homeLayout/Header";
import styles from "./page.module.css";

export default function Home() {
  return (
    <div className={styles.page}>
      <Header />
      <main className={styles.main}>
        <section className={styles.hero}>
          <h1 className={`${styles.fontDisplay} ${styles.heroTitle}`}>
            The Infrastructure Powering
            <br />
            <span className={styles.heroAccent}>
              Africa&apos;s Digital Economy
            </span>
          </h1>
          <p className={styles.heroCopy}>
            Build, launch, and scale financial products with Paymo&apos;s
            Banking-as-a-Service platform. From payments to wallets to FX — one
            API, entire continent.
          </p>
          <div className={styles.heroCta}>
            <button
              type="button"
              className={styles.btnPrimaryLg}
              onClick={() => alert("Redirecting to dashboard...")}
            >
              Get Started Free
            </button>
            <button
              type="button"
              className={styles.btnGhostLg}
              onClick={() => alert("Opening demo environment...")}
            >
              Watch Demo
            </button>
          </div>
        </section>

        {/* Spacer so we can verify sticky header on scroll */}
        <section className={styles.spacer}>
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className={styles.placeholder}>
              <h3 className={styles.fontDisplay}>Section {i + 1}</h3>
              <p>
                Body content placeholder — kept as-is from the original layout.
                Scroll the page to confirm the sticky header stays pinned and
                that the mobile drawer closes correctly when navigating.
              </p>
            </div>
          ))}
        </section>
      </main>
    </div>
  );
}
