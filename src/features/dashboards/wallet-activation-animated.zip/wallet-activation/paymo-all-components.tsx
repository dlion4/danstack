'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  ArrowDownLeft,
  ArrowLeft,
  ArrowLeftRight,
  ArrowRight,
  ArrowRightLeft,
  ArrowUpRight,
  Banknote,
  Bell,
  BellOff,
  Bitcoin,
  Briefcase,
  Building2,
  Check,
  CheckCircle2,
  ChevronRight,
  CircleDollarSign,
  CircleDot,
  Clock,
  Code,
  Copy,
  CreditCard,
  Download,
  Eye,
  FileText,
  Fingerprint,
  Info,
  Laptop,
  LayoutGrid,
  Link2,
  Loader2,
  Lock,
  LogOut,
  Mail,
  Map,
  MapPin,
  MessageSquare,
  Monitor,
  MonitorSmartphone,
  Moon,
  PartyPopper,
  Phone,
  PiggyBank,
  Plus,
  QrCode,
  Route,
  Save,
  ScrollText,
  ShieldAlert,
  ShieldCheck,
  ShieldPlus,
  SlidersHorizontal,
  Smartphone,
  Sparkles,
  TrendingUp,
  Unlink,
  Wallet,
  X,
  XCircle,
  Zap
} from 'lucide-react';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'framer-motion';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { accessLogs, activeLinks as initialLinks, autoRules, consentItems, dashboards, healthFeed, linkableAccounts, relocationSteps, sessions, tourSteps, usePayMoStore, wallet } from './paymo-data-store';
import type { AccessLog, ActiveLink, HealthFeedItem, ModalId } from './paymo-data-store';

// --- components/paymo/modals/wallet-modals.tsx ---

/* -------------------------------------------------------------------------- */
/*  Icon helper – maps icon name strings from mock data to Lucide components  */
/* -------------------------------------------------------------------------- */
const WalletIconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  ArrowDownLeft,
  ArrowUpRight,
  PiggyBank,
  Wallet,
  Banknote,
  CreditCard,
};

function FeedIcon({ name, bg, color }: { name: string; bg: string; color: string }) {
  const Icon = WalletIconMap[name] ?? Wallet;
  return (
    <div className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${bg}`}>
      <Icon className={`size-4 ${color}`} />
    </div>
  );
}

/* ========================================================================== */
/*  1. WalletDetailModal                                                      */
/* ========================================================================== */
export function WalletDetailModal() {
  const open = usePayMoStore((s) => s.modals.walletDetail);
  const close = usePayMoStore((s) => s.closeModal);
  const [copied, setCopied] = useState<string | null>(null);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopied(label);
    toast.success(`${label} copied to clipboard`);
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && close("walletDetail")}>
      <DialogContent className="sm:max-w-xl max-h-[90vh] overflow-y-auto paymo-scroll">
        {/* ---- Gradient Card ---- */}
        <div className="wallet-gradient rounded-2xl p-6 text-white relative overflow-hidden">
          {/* Decorative circles */}
          <div className="pointer-events-none absolute -right-6 -top-6 h-32 w-32 rounded-full bg-white/10" />
          <div className="pointer-events-none absolute -bottom-8 -left-8 h-40 w-40 rounded-full bg-white/5" />

          {/* Top row: Initials + Holder info */}
          <div className="relative flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-full bg-white/20 text-sm font-bold">
                {wallet.initials}
              </div>
              <div>
                <p className="text-sm font-medium text-white/80">{wallet.holder}</p>
                <div className="mt-1 flex items-center gap-2">
                  <Badge className="bg-white/20 text-white border-white/30 hover:bg-white/30 text-[10px]">
                    {wallet.tier}
                  </Badge>
                  <Badge className="bg-emerald-500/80 text-white border-emerald-400/40 hover:bg-emerald-500/90 text-[10px]">
                    {wallet.status}
                  </Badge>
                </div>
              </div>
            </div>
          </div>

          {/* Balance */}
          <div className="relative mt-6">
            <p className="text-xs font-medium uppercase tracking-wider text-white/60">
              Available Balance
            </p>
            <p className="mt-1 text-3xl font-bold tracking-tight">{wallet.balance}</p>
          </div>

          {/* Account details row */}
          <div className="relative mt-5 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-white/70">
            <button
              onClick={() => copyToClipboard(wallet.accountNumber, "Account Number")}
              className="flex items-center gap-1.5 hover:text-white transition-colors"
            >
              <span>Acct: {wallet.accountNumber}</span>
              {copied === "Account Number" ? (
                <CheckCircle2 className="size-3 text-emerald-300" />
              ) : (
                <Copy className="size-3" />
              )}
            </button>
            <button
              onClick={() => copyToClipboard(wallet.walletId, "Wallet ID")}
              className="flex items-center gap-1.5 hover:text-white transition-colors"
            >
              <span>ID: {wallet.walletId}</span>
              {copied === "Wallet ID" ? (
                <CheckCircle2 className="size-3 text-emerald-300" />
              ) : (
                <Copy className="size-3" />
              )}
            </button>
          </div>
        </div>

        {/* ---- Stats Grid ---- */}
        <div className="grid grid-cols-2 gap-3">
          {[
            { label: "Linked Dashboards", value: String(wallet.linkedDashboards), icon: Monitor },
            { label: "Pending Incoming", value: wallet.pendingIncoming, icon: ArrowDownLeft },
            { label: "Pending Outgoing", value: wallet.pendingOutgoing, icon: ArrowUpRight },
            { label: "Consolidated", value: wallet.consolidated, icon: CircleDollarSign },
          ].map((item) => (
            <div
              key={item.label}
              className="flex items-center gap-3 rounded-xl border bg-muted/40 p-3"
            >
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                <item.icon className="size-4 text-primary" />
              </div>
              <div className="min-w-0">
                <p className="truncate text-[11px] text-muted-foreground">{item.label}</p>
                <p className="text-sm font-semibold">{item.value}</p>
              </div>
            </div>
          ))}
        </div>

        {/* ---- Currencies ---- */}
        <div>
          <p className="mb-2 text-xs font-medium text-muted-foreground uppercase tracking-wider">
            Supported Currencies
          </p>
          <div className="flex flex-wrap gap-1.5">
            {wallet.currencies.map((c) => (
              <Badge key={c} variant="outline" className="text-xs font-medium">
                {c}
              </Badge>
            ))}
          </div>
        </div>

        {/* ---- Security ---- */}
        <div>
          <p className="mb-2 text-xs font-medium text-muted-foreground uppercase tracking-wider">
            Security
          </p>
          <div className="grid grid-cols-2 gap-2">
            {[
              { label: "PIN Lock", enabled: wallet.security.pin, icon: ShieldCheck },
              { label: "Biometric", enabled: wallet.security.biometric, icon: Fingerprint },
              { label: "Two-Factor Auth", enabled: wallet.security.twoFA, icon: Smartphone },
              {
                label: "Active Sessions",
                enabled: wallet.security.sessions > 0,
                detail: String(wallet.security.sessions),
                icon: Monitor,
              },
            ].map((s) => (
              <div
                key={s.label}
                className="flex items-center gap-2.5 rounded-lg border px-3 py-2.5"
              >
                <s.icon
                  className={`size-4 ${s.enabled ? "text-emerald-500" : "text-muted-foreground/40"}`}
                />
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-medium">{s.label}</p>
                  <p className="text-[11px] text-muted-foreground">
                    {"detail" in s ? `${s.detail} sessions` : s.enabled ? "Enabled" : "Disabled"}
                  </p>
                </div>
                <div
                  className={`h-2 w-2 rounded-full ${
                    s.enabled ? "bg-emerald-500" : "bg-muted-foreground/30"
                  }`}
                />
              </div>
            ))}
          </div>
        </div>

        {/* ---- Wallet Meta ---- */}
        <div className="flex items-center justify-between rounded-lg border px-4 py-3 text-xs text-muted-foreground">
          <span>Opened {wallet.opened}</span>
          <span className="font-medium text-foreground">{wallet.age}</span>
        </div>

        {/* ---- Footer Actions ---- */}
        <DialogFooter className="sm:justify-between">
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              close("walletDetail");
              toast.info("Statement download initiated");
            }}
          >
            <Banknote className="size-4" />
            Download Statement
          </Button>
          <Button
            size="sm"
            onClick={() => {
              close("walletDetail");
            }}
          >
            <Plus className="size-4" />
            Top Up Wallet
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ========================================================================== */
/*  2. WalletFundModal                                                        */
/* ========================================================================== */

const fundSources = [
  { label: "M-Pesa", value: "mpesa" },
  { label: "Bank Transfer", value: "bank" },
  { label: "Debit Card", value: "card" },
  { label: "PayMo Internal", value: "internal" },
];

const quickAmounts = ["1,000", "5,000", "10,000", "25,000", "50,000", "100,000"];

export function WalletFundModal() {
  const open = usePayMoStore((s) => s.modals.walletFund);
  const close = usePayMoStore((s) => s.closeModal);

  const [source, setSource] = useState("mpesa");
  const [amount, setAmount] = useState("");
  const [reference, setReference] = useState("");
  const [isFunding, setIsFunding] = useState(false);

  const handleFund = () => {
    if (!amount.replace(/,/g, "")) {
      toast.error("Please enter a valid amount");
      return;
    }
    setIsFunding(true);
    setTimeout(() => {
      setIsFunding(false);
      toast.success(
        `KES ${amount} funding initiated via ${fundSources.find((s) => s.value === source)?.label}. You will receive a confirmation shortly.`,
      );
      setAmount("");
      setReference("");
      close("walletFund");
    }, 1500);
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && close("walletFund")}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
              <Plus className="size-4 text-primary" />
            </div>
            Fund Wallet
          </DialogTitle>
          <DialogDescription>
            Add funds to your PayMo KES Wallet from an external source.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* ---- Source ---- */}
          <div className="space-y-2">
            <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
              Fund Source
            </label>
            <div className="grid grid-cols-2 gap-2">
              {fundSources.map((s) => (
                <button
                  key={s.value}
                  type="button"
                  onClick={() => setSource(s.value)}
                  className={`rounded-lg border px-3 py-2.5 text-left text-sm font-medium transition-all ${
                    source === s.value
                      ? "border-primary bg-primary/5 text-primary ring-1 ring-primary/20"
                      : "border-border hover:bg-muted/50"
                  }`}
                >
                  <ArrowRightLeft className={`mb-1 size-4 ${source === s.value ? "text-primary" : "text-muted-foreground"}`} />
                  <span>{s.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* ---- Amount ---- */}
          <div className="space-y-2">
            <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
              Amount (KES)
            </label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">
                KES
              </span>
              <Input
                placeholder="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="pl-12 text-lg font-semibold tabular-nums"
              />
            </div>
            <div className="flex flex-wrap gap-1.5">
              {quickAmounts.map((qa) => (
                <button
                  key={qa}
                  type="button"
                  onClick={() => setAmount(qa)}
                  className="rounded-md border px-2.5 py-1 text-xs font-medium text-muted-foreground transition-colors hover:border-primary hover:text-primary"
                >
                  {qa}
                </button>
              ))}
            </div>
          </div>

          {/* ---- Reference ---- */}
          <div className="space-y-2">
            <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
              Reference (Optional)
            </label>
            <Input
              placeholder="e.g. Salary, Freelance payment"
              value={reference}
              onChange={(e) => setReference(e.target.value)}
            />
          </div>

          {/* ---- Destination Preview ---- */}
          <div className="rounded-lg border bg-muted/40 px-4 py-3">
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Funding to</span>
              <span className="font-medium">{wallet.accountNumber}</span>
            </div>
            <div className="mt-1 flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Current Balance</span>
              <span className="font-semibold">{wallet.balance}</span>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => close("walletFund")}
            disabled={isFunding}
          >
            Cancel
          </Button>
          <Button onClick={handleFund} disabled={isFunding}>
            {isFunding ? (
              <span className="flex items-center gap-2">
                <span className="size-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
                Processing…
              </span>
            ) : (
              <>
                <CircleDollarSign className="size-4" />
                Fund Wallet
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ========================================================================== */
/*  3. WalletHealthModal                                                      */
/* ========================================================================== */

export function WalletHealthModal() {
  const open = usePayMoStore((s) => s.modals.walletHealth);
  const close = usePayMoStore((s) => s.closeModal);

  return (
    <Dialog open={open} onOpenChange={(v) => !v && close("walletHealth")}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-100">
              <ShieldCheck className="size-4 text-emerald-600" />
            </div>
            Wallet Health
          </DialogTitle>
          <DialogDescription>
            Recent wallet activity and transaction pulse for {wallet.accountNumber}.
          </DialogDescription>
        </DialogHeader>

        {/* ---- Summary Strip ---- */}
        <div className="grid grid-cols-3 gap-3">
          <div className="rounded-xl bg-emerald-50 p-3 text-center dark:bg-emerald-950/30">
            <p className="text-[11px] font-medium text-emerald-600">Incoming</p>
            <p className="mt-0.5 text-sm font-bold text-emerald-700">+KES 125,000</p>
          </div>
          <div className="rounded-xl bg-amber-50 p-3 text-center dark:bg-amber-950/30">
            <p className="text-[11px] font-medium text-amber-600">Outgoing</p>
            <p className="mt-0.5 text-sm font-bold text-amber-700">-KES 205,000</p>
          </div>
          <div className="rounded-xl bg-sky-50 p-3 text-center dark:bg-sky-950/30">
            <p className="text-[11px] font-medium text-sky-600">Net</p>
            <p className="mt-0.5 text-sm font-bold text-sky-700">-KES 80,000</p>
          </div>
        </div>

        {/* ---- Health Score ---- */}
        <div className="flex items-center gap-3 rounded-xl border px-4 py-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-emerald-100">
            <ShieldCheck className="size-5 text-emerald-600" />
          </div>
          <div className="flex-1">
            <div className="flex items-center justify-between">
              <p className="text-sm font-semibold">Wallet Health Score</p>
              <span className="text-lg font-bold text-emerald-600">92/100</span>
            </div>
            <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-muted">
              <div
                className="h-full rounded-full bg-emerald-500 transition-all"
                style={{ width: "92%" }}
              />
            </div>
          </div>
        </div>

        {/* ---- Activity Feed ---- */}
        <div>
          <p className="mb-2 text-xs font-medium text-muted-foreground uppercase tracking-wider">
            Recent Activity
          </p>
          <div className="space-y-1">
            {healthFeed.map((item: HealthFeedItem, idx: number) => (
              <div
                key={idx}
                className="flex items-start gap-3 rounded-lg border px-3 py-3 transition-colors hover:bg-muted/40"
              >
                <FeedIcon name={item.icon} bg={item.bg} color={item.color} />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium">{item.title}</p>
                  <p className="mt-0.5 text-[11px] text-muted-foreground">{item.desc}</p>
                </div>
                <div className="shrink-0 text-right">
                  <p
                    className={`text-sm font-semibold ${
                      item.amount.startsWith("+") ? "text-emerald-600" : "text-amber-600"
                    }`}
                  >
                    {item.amount}
                  </p>
                  <p className="mt-0.5 text-[11px] text-muted-foreground">{item.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ---- Footer ---- */}
        <DialogFooter>
          <Button variant="outline" onClick={() => close("walletHealth")}>
            Close
          </Button>
          <Button
            onClick={() => {
              close("walletHealth");
              toast.info("Full transaction history loaded");
            }}
          >
            View All Transactions
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// --- components/paymo/modals/qr-modal.tsx ---

export function ShareQRModal() {
  const { modals, closeModal } = usePayMoStore();
  const [copied, setCopied] = useState(false);

  const copyWalletId = useCallback(() => {
    navigator.clipboard.writeText(wallet.walletId);
    setCopied(true);
    toast.success('Wallet ID copied');
    setTimeout(() => setCopied(false), 2000);
  }, []);

  return (
    <Dialog
      open={modals.shareQR}
      onOpenChange={(open) => { if (!open) closeModal('shareQR'); }}
    >
      <DialogContent className="sm:max-w-sm gap-0 p-0">
        <DialogHeader className="p-6 pb-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-100 text-emerald-600">
              <QrCode className="h-5 w-5" />
            </div>
            <div>
              <DialogTitle>Share Wallet QR</DialogTitle>
              <DialogDescription>
                Scan to send money to this wallet.
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <div className="px-6 pb-4 flex flex-col items-center gap-4">
          <div className="w-48 h-48 bg-white rounded-2xl border flex items-center justify-center shadow-sm">
            <QrCode className="h-36 w-36 text-foreground" />
          </div>
          <div className="text-center">
            <code className="text-sm bg-muted px-4 py-2 rounded-lg font-mono">
              {wallet.accountNumber}
            </code>
            <p className="text-xs text-muted-foreground mt-2">
              QR codes expire after 10 minutes and rotate automatically for security.
            </p>
          </div>
        </div>

        <DialogFooter className="p-6 pt-4 gap-2">
          <Button variant="outline" onClick={() => closeModal('shareQR')}>
            Close
          </Button>
          <Button onClick={copyWalletId}>
            {copied ? (
              <><CheckCircle2 className="h-4 w-4 mr-2" /> Copied</>
            ) : (
              <><Copy className="h-4 w-4 mr-2" /> Copy Wallet ID</>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// --- components/paymo/modals/activation-modal.tsx ---

/* -------------------------------------------------------------------------- */
/*  Constants                                                                  */
/* -------------------------------------------------------------------------- */

const STEP_LABELS = ["1. Consent", "2. PIN", "3. Tour"] as const;
const TOTAL_STEPS = 3;
const MANDATORY_COUNT = 9; // first 9 are mandatory

const activatableDashboards = dashboards.filter(
  (d) => d.status !== "Active"
);

/* -------------------------------------------------------------------------- */
/*  Component                                                                  */
/* -------------------------------------------------------------------------- */

export function DashboardActivationModal() {
  /* ---- store ---- */
  const modals = usePayMoStore((s) => s.modals);
  const closeModal = usePayMoStore((s) => s.closeModal);
  const selectedDashboard = usePayMoStore((s) => s.selectedDashboard);
  const setSelectedDashboard = usePayMoStore((s) => s.setSelectedDashboard);
  const consentAccepted = usePayMoStore((s) => s.consentAccepted);
  const toggleConsent = usePayMoStore((s) => s.toggleConsent);
  const acceptAllConsent = usePayMoStore((s) => s.acceptAllConsent);
  const pinEntered = usePayMoStore((s) => s.pinEntered);
  const setPinEntered = usePayMoStore((s) => s.setPinEntered);
  const isActivating = usePayMoStore((s) => s.isActivating);
  const setIsActivating = usePayMoStore((s) => s.setIsActivating);
  const activationComplete = usePayMoStore((s) => s.activationComplete);
  const setActivationComplete = usePayMoStore((s) => s.setActivationComplete);

  const open = modals.activateDashboard;

  /* ---- local step state ---- */
  const [step, setStep] = useState(0);
  const [tourIndex, setTourIndex] = useState(0);

  /* PIN refs */
  const pinRefs = useRef<(HTMLInputElement | null)[]>([]);

  /* Reset tour index when entering step 3 */
  useEffect(() => {
    if (step === 2) {
      // eslint-disable-next-line react-hooks/set-state-in-effect -- intentional UI reset on step change
      setTourIndex(0);
    }
  }, [step]);

  /* Auto-focus first PIN field when entering step 1 */
  useEffect(() => {
    if (step === 1) {
      // small delay to let the DOM paint
      const t = setTimeout(() => pinRefs.current[0]?.focus(), 100);
      return () => clearTimeout(t);
    }
  }, [step]);

  /* ---- derived ---- */
  const acceptedCount = consentAccepted.filter(Boolean).length;
  const mandatoryAccepted = consentAccepted.slice(0, MANDATORY_COUNT).every(Boolean);
  const progressPercent =
    step === 0
      ? Math.round((acceptedCount / consentItems.length) * 33)
      : step === 1
        ? 66
        : Math.round(((tourIndex + 1) / tourSteps.length) * 34) + 66;

  /* ---- handlers ---- */
  const handleDashboardChange = useCallback(
    (name: string) => {
      setSelectedDashboard(name);
      setStep(0);
      setTourIndex(0);
    },
    [setSelectedDashboard]
  );

  const handlePinInput = useCallback(
    (index: number, value: string) => {
      // Only accept digits
      const digit = value.replace(/\D/g, "").slice(-1);
      const chars = pinEntered.split("");
      chars[index] = digit;
      const newPin = chars.join("");
      setPinEntered(newPin);

      // Auto-advance
      if (digit && index < 3) {
        pinRefs.current[index + 1]?.focus();
      }
    },
    [pinEntered, setPinEntered]
  );

  const handlePinKeyDown = useCallback(
    (index: number, e: React.KeyboardEvent) => {
      if (e.key === "Backspace" && !pinEntered[index] && index > 0) {
        pinRefs.current[index - 1]?.focus();
      }
    },
    [pinEntered]
  );

  const handleVerifyPin = useCallback(async () => {
    setIsActivating(true);
    // Simulate activation delay
    await new Promise((r) => setTimeout(r, 2000));
    setActivationComplete(true);
    setIsActivating(false);
    toast.success(`${selectedDashboard} activated successfully!`);
    setStep(2);
  }, [
    setIsActivating,
    setActivationComplete,
    selectedDashboard,
  ]);

  const handleClose = useCallback(() => {
    closeModal("activateDashboard" as ModalId);
    // Reset local state after close
    setTimeout(() => {
      setStep(0);
      setTourIndex(0);
    }, 200);
  }, [closeModal]);

  const handleFinishTour = useCallback(() => {
    toast.success(
      `Welcome to ${selectedDashboard}! You're all set.`,
      {
        description: "Your dashboard is ready to use.",
      }
    );
    handleClose();
  }, [selectedDashboard, handleClose]);

  /* ---- step title ---- */
  const stepTitle =
    step === 0
      ? `Activate ${selectedDashboard} — Terms & Compliance`
      : step === 1
        ? "Confirm Your PIN"
        : `Welcome to ${selectedDashboard}`;

  /* ====================================================================== */
  /*  Render                                                                 */
  /* ====================================================================== */

  return (
    <Dialog open={open} onOpenChange={(v) => !v && handleClose()}>
      <DialogContent
        className="max-w-2xl max-h-[90vh] flex flex-col gap-0 p-0 overflow-hidden"
        showCloseButton={false}
      >
        {/* ---- Header ---- */}
        <div className="px-6 pt-6 pb-4 space-y-4">
          <DialogHeader className="text-left space-y-1">
            <DialogTitle className="text-xl font-bold tracking-tight">
              {stepTitle}
            </DialogTitle>
            <DialogDescription className="text-sm text-muted-foreground">
              {step === 0 &&
                "Review and accept the following terms to proceed with activation."}
              {step === 1 &&
                `Enter your 4-digit PayMo PIN to activate ${selectedDashboard}. This is a security requirement.`}
              {step === 2 &&
                "Take a quick tour of your new dashboard features."}
            </DialogDescription>
          </DialogHeader>

          {/* Dashboard selector */}
          <div className="flex items-center gap-3">
            <span className="text-sm font-medium text-muted-foreground whitespace-nowrap">
              Dashboard:
            </span>
            <Select
              value={selectedDashboard}
              onValueChange={handleDashboardChange}
            >
              <SelectTrigger className="w-full max-w-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {activatableDashboards.map((d) => (
                  <SelectItem key={d.id} value={d.name}>
                    <span className="flex items-center gap-2">
                      {d.name}
                      <Badge
                        variant={
                          d.variant === "danger"
                            ? "destructive"
                            : d.variant === "warning"
                              ? "outline"
                              : "secondary"
                        }
                        className="text-[10px] px-1.5 py-0"
                      >
                        {d.status}
                      </Badge>
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Separator />

          {/* ---- Step indicator ---- */}
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-2">
              {STEP_LABELS.map((label, i) => {
                const isActive = i === step;
                const isDone = i < step;
                return (
                  <div key={label} className="flex items-center gap-2 flex-1">
                    <div
                      className={`flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-medium transition-colors ${
                        isActive
                          ? "bg-primary text-primary-foreground"
                          : isDone
                            ? "bg-primary/10 text-primary"
                            : "bg-muted text-muted-foreground"
                      }`}
                    >
                      {isDone ? (
                        <Check className="size-3.5" />
                      ) : (
                        <span className="size-3.5 flex items-center justify-center rounded-full border border-current text-[10px]">
                          {i + 1}
                        </span>
                      )}
                      {label}
                    </div>
                    {i < TOTAL_STEPS - 1 && (
                      <ChevronRight
                        className={`size-4 shrink-0 ${
                          i < step ? "text-primary" : "text-muted-foreground/40"
                        }`}
                      />
                    )}
                  </div>
                );
              })}
            </div>
            <Progress value={Math.min(progressPercent, 100)} className="h-1.5" />
          </div>
        </div>

        {/* ---- Scrollable content area ---- */}
        <div className="flex-1 overflow-y-auto px-6 pb-6">
          {/* ============ STEP 0: CONSENT ============ */}
          {step === 0 && (
            <div className="space-y-1">
              {consentItems.map((item, idx) => {
                const checked = consentAccepted[idx];
                return (
                  <div
                    key={item.name}
                    className={`flex items-start gap-3 rounded-lg border p-3 transition-colors ${
                      checked
                        ? "border-primary/30 bg-primary/5"
                        : "border-border hover:border-muted-foreground/30"
                    }`}
                  >
                    <Checkbox
                      checked={checked}
                      onCheckedChange={() => toggleConsent(idx)}
                      className="mt-0.5"
                      aria-label={`Accept ${item.name}`}
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-semibold leading-tight">
                          {item.name}
                        </span>
                        {item.optional && (
                          <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
                            Optional
                          </Badge>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">
                        {item.desc}
                      </p>
                    </div>
                  </div>
                );
              })}

              {/* Accept all + counter */}
              <div className="flex items-center justify-between pt-3">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={acceptAllConsent}
                  className="text-xs"
                >
                  <ShieldCheck className="size-3.5 mr-1.5" />
                  Accept All
                </Button>
                <span className="text-xs text-muted-foreground">
                  {acceptedCount} of {consentItems.length} accepted
                </span>
              </div>
            </div>
          )}

          {/* ============ STEP 1: PIN ============ */}
          {step === 1 && (
            <div className="flex flex-col items-center gap-6 py-6">
              <div className="flex items-center gap-2 rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800 w-full max-w-md">
                <AlertTriangle className="size-4 shrink-0" />
                <span>
                  Enter your 4-digit PayMo PIN to activate{" "}
                  <strong>{selectedDashboard}</strong>. This is a security
                  requirement.
                </span>
              </div>

              <div className="flex items-center gap-3">
                {Array.from({ length: 4 }).map((_, i) => (
                  <Input
                    key={i}
                    ref={(el) => {
                      pinRefs.current[i] = el;
                    }}
                    type="password"
                    inputMode="numeric"
                    maxLength={1}
                    value={pinEntered[i] ?? ""}
                    onChange={(e) => handlePinInput(i, e.target.value)}
                    onKeyDown={(e) => handlePinKeyDown(i, e)}
                    className={`h-14 w-14 text-center text-2xl font-bold tracking-widest ${
                      pinEntered[i]
                        ? "border-primary ring-primary/20 ring-2"
                        : ""
                    }`}
                    disabled={isActivating}
                    aria-label={`PIN digit ${i + 1}`}
                  />
                ))}
              </div>

              {isActivating && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <div className="size-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />
                  Activating {selectedDashboard}…
                </div>
              )}

              {activationComplete && (
                <div className="flex items-center gap-2 text-sm text-emerald-600 font-medium">
                  <Check className="size-4" />
                  PIN verified — activation complete
                </div>
              )}
            </div>
          )}

          {/* ============ STEP 2: TOUR ============ */}
          {step === 2 && (
            <div className="py-4 space-y-6">
              {/* Stepper dots */}
              <div className="flex items-center gap-1.5 justify-center">
                {tourSteps.map((_, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => setTourIndex(i)}
                    className={`size-2.5 rounded-full transition-all ${
                      i === tourIndex
                        ? "bg-primary scale-125"
                        : i < tourIndex
                          ? "bg-primary/50"
                          : "bg-muted-foreground/25"
                    }`}
                    aria-label={`Go to tour step ${i + 1}`}
                  />
                ))}
              </div>

              {/* Tour card */}
              <div className="relative rounded-xl border bg-muted/30 p-6 text-center space-y-3">
                <div className="mx-auto flex size-12 items-center justify-center rounded-full bg-primary/10">
                  {tourIndex === 0 ? (
                    <PartyPopper className="size-6 text-primary" />
                  ) : tourIndex < 5 ? (
                    <Map className="size-6 text-primary" />
                  ) : (
                    <ShieldCheck className="size-6 text-primary" />
                  )}
                </div>
                <div className="space-y-1">
                  <h3 className="text-base font-semibold">
                    Step {tourIndex + 1}: {tourSteps[tourIndex].title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed max-w-md mx-auto">
                    {tourSteps[tourIndex].desc}
                  </p>
                </div>
              </div>

              {/* Step counter */}
              <p className="text-center text-xs text-muted-foreground">
                {tourIndex + 1} of {tourSteps.length}
              </p>
            </div>
          )}
        </div>

        {/* ---- Footer ---- */}
        <Separator />
        <DialogFooter className="px-6 py-4 gap-2 sm:justify-between">
          {/* Left side: back or close */}
          <div>
            {step > 0 && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setStep((s) => s - 1)}
                disabled={isActivating}
              >
                <ArrowLeft className="size-3.5 mr-1.5" />
                Back
              </Button>
            )}
          </div>

          {/* Right side: primary action */}
          <div className="flex gap-2">
            {step === 0 && (
              <Button
                size="sm"
                disabled={!mandatoryAccepted}
                onClick={() => setStep(1)}
              >
                Continue to PIN Verification
                <ArrowRight className="size-3.5 ml-1.5" />
              </Button>
            )}

            {step === 1 && (
              <Button
                size="sm"
                disabled={pinEntered.length < 4 || isActivating}
                onClick={handleVerifyPin}
              >
                {isActivating ? (
                  <>
                    <div className="size-3.5 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent mr-1.5" />
                    Verifying…
                  </>
                ) : (
                  <>
                    <Lock className="size-3.5 mr-1.5" />
                    Verify &amp; Activate
                  </>
                )}
              </Button>
            )}

            {step === 2 && (
              <>
                <Button
                  variant="outline"
                  size="sm"
                  disabled={tourIndex === 0}
                  onClick={() => setTourIndex((i) => i - 1)}
                >
                  <ArrowLeft className="size-3.5 mr-1.5" />
                  Previous
                </Button>
                {tourIndex < tourSteps.length - 1 ? (
                  <Button
                    size="sm"
                    onClick={() => setTourIndex((i) => i + 1)}
                  >
                    Next
                    <ArrowRight className="size-3.5 ml-1.5" />
                  </Button>
                ) : (
                  <Button size="sm" onClick={handleFinishTour}>
                    <PartyPopper className="size-3.5 mr-1.5" />
                    Enter Dashboard
                  </Button>
                )}
              </>
            )}
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// --- components/paymo/modals/linking-modals.tsx ---

/* -------------------------------------------------------------------------- */
/*  Shared helpers                                                            */
/* -------------------------------------------------------------------------- */

const STATUS_STYLES: Record<
  string,
  { badge: "default" | "destructive" | "outline" | "secondary"; dot: string }
> = {
  Linked: { badge: "default", dot: "bg-emerald-500" },
  "Link Revoked": { badge: "destructive", dot: "bg-red-500" },
  "Link Requested": { badge: "outline", dot: "bg-amber-500" },
  Unlinked: { badge: "secondary", dot: "bg-muted-foreground" },
};

const CIRCLE_COLORS = [
  "bg-emerald-500",
  "bg-purple-500",
  "bg-amber-500",
  "bg-sky-500",
  "bg-red-500",
  "bg-indigo-500",
  "bg-pink-500",
  "bg-teal-500",
  "bg-orange-500",
];

function getColorForName(name: string) {
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }
  return CIRCLE_COLORS[Math.abs(hash) % CIRCLE_COLORS.length];
}

/* ======================================================================== */
/*  1. LinkAccountModal                                                      */
/* ======================================================================== */

type FilterTab = "All" | "Linked" | "Pending" | "Unlinked";

const FILTER_TABS: FilterTab[] = ["All", "Linked", "Pending", "Unlinked"];

export function LinkAccountModal() {
  const modals = usePayMoStore((s) => s.modals);
  const closeModal = usePayMoStore((s) => s.closeModal);
  const linkedAccounts = usePayMoStore((s) => s.linkedAccounts);
  const unlinkAccount = usePayMoStore((s) => s.unlinkAccount);
  const relinkAccount = usePayMoStore((s) => s.relinkAccount);
  const setUnlinkTargetId = usePayMoStore((s) => s.setUnlinkTargetId);
  const openModal = usePayMoStore((s) => s.openModal);

  const open = modals.linkAccount;
  const [filter, setFilter] = useState<FilterTab>("All");

  /* Local status overrides — in a real app these would update the backend */
  const [localStatuses, setLocalStatuses] = useState<Record<number, string>>({});

  const getStatus = useCallback(
    (acct: (typeof linkableAccounts)[number]) => {
      if (localStatuses[acct.id]) return localStatuses[acct.id] as typeof acct.status;
      return acct.status;
    },
    [localStatuses]
  );

  /* Counts */
  const counts = useMemo(() => {
    const c = { linked: 0, pending: 0, unlinked: 0 };
    linkableAccounts.forEach((a) => {
      const s = getStatus(a);
      if (s === "Linked") c.linked++;
      else if (s === "Link Requested") c.pending++;
      else if (s === "Unlinked") c.unlinked++;
    });
    return c;
  }, [getStatus]);

  /* Filtered list */
  const filtered = useMemo(() => {
    return linkableAccounts.filter((a) => {
      const s = getStatus(a);
      if (filter === "All") return true;
      if (filter === "Linked") return s === "Linked";
      if (filter === "Pending") return s === "Link Requested";
      if (filter === "Unlinked")
        return s === "Unlinked" || s === "Link Revoked";
      return true;
    });
  }, [filter, getStatus]);

  /* Actions */
  const handleLink = useCallback(
    (id: number, name: string) => {
      setLocalStatuses((prev) => ({ ...prev, [id]: "Link Requested" }));
      toast.success(`Link request sent`, {
        description: `${name} has been requested for linking.`,
      });
    },
    []
  );

  const handleUnlink = useCallback(
    (id: number, name: string) => {
      setLocalStatuses((prev) => ({ ...prev, [id]: "Unlinked" }));
      toast.success(`Account unlinked`, {
        description: `${name} has been unlinked from this dashboard.`,
      });
    },
    []
  );

  const handleRelink = useCallback(
    (id: number, name: string) => {
      setLocalStatuses((prev) => ({ ...prev, [id]: "Link Requested" }));
      toast.success(`Re-link requested`, {
        description: `${name} re-link request has been submitted.`,
      });
    },
    []
  );

  const handleCancelRequest = useCallback(
    (id: number, name: string) => {
      setLocalStatuses((prev) => ({ ...prev, [id]: "Unlinked" }));
      toast.info(`Link request cancelled`, {
        description: `The link request for ${name} has been cancelled.`,
      });
    },
    []
  );

  const handleClose = useCallback(() => {
    closeModal("linkAccount" as ModalId);
    setFilter("All");
    setLocalStatuses({});
  }, [closeModal]);

  const handleOpenUnlinkConfirm = useCallback(
    (id: number) => {
      setUnlinkTargetId(id);
      openModal("unlinkAccount" as ModalId);
    },
    [setUnlinkTargetId, openModal]
  );

  return (
    <Dialog open={open} onOpenChange={(v) => !v && handleClose()}>
      <DialogContent className="max-w-2xl max-h-[85vh] flex flex-col gap-0 p-0 overflow-hidden">
        {/* Header */}
        <div className="px-6 pt-6 pb-4 space-y-4">
          <DialogHeader className="text-left space-y-1">
            <DialogTitle className="text-xl font-bold tracking-tight flex items-center gap-2">
              <Link2 className="size-5 text-primary" />
              Link Accounts
            </DialogTitle>
            <DialogDescription className="text-sm text-muted-foreground">
              Manage your cross-dashboard account connections.
            </DialogDescription>
          </DialogHeader>

          {/* Summary strip */}
          <div className="flex items-center gap-4 rounded-lg border bg-muted/40 px-4 py-2.5">
            <div className="flex items-center gap-2">
              <div className="size-2 rounded-full bg-emerald-500" />
              <span className="text-xs font-medium">
                <span className="text-base font-bold text-foreground">
                  {counts.linked}
                </span>{" "}
                linked
              </span>
            </div>
            <Separator orientation="vertical" className="h-4" />
            <div className="flex items-center gap-2">
              <div className="size-2 rounded-full bg-amber-500" />
              <span className="text-xs font-medium">
                <span className="text-base font-bold text-foreground">
                  {counts.pending}
                </span>{" "}
                pending
              </span>
            </div>
            <Separator orientation="vertical" className="h-4" />
            <div className="flex items-center gap-2">
              <div className="size-2 rounded-full bg-muted-foreground" />
              <span className="text-xs font-medium">
                <span className="text-base font-bold text-foreground">
                  {counts.unlinked}
                </span>{" "}
                unlinked
              </span>
            </div>
          </div>

          {/* Filter tabs */}
          <div className="flex items-center gap-1 rounded-lg border bg-muted/30 p-1">
            {FILTER_TABS.map((tab) => (
              <button
                key={tab}
                type="button"
                onClick={() => setFilter(tab)}
                className={`flex-1 rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
                  filter === tab
                    ? "bg-background text-foreground shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          <Separator />
        </div>

        {/* Scrollable list */}
        <ScrollArea className="flex-1 px-6">
          <div className="space-y-2 pb-4">
            {filtered.length === 0 && (
              <div className="py-12 text-center text-sm text-muted-foreground">
                No accounts found for this filter.
              </div>
            )}
            {filtered.map((acct) => {
              const status = getStatus(acct);
              const styles = STATUS_STYLES[status] ?? STATUS_STYLES.Unlinked;
              const circleColor = getColorForName(acct.name);

              return (
                <div
                  key={acct.id}
                  className="flex items-center gap-4 rounded-lg border p-4 transition-colors hover:bg-muted/30"
                >
                  {/* Icon circle */}
                  <div
                    className={`flex size-10 shrink-0 items-center justify-center rounded-full text-white font-bold text-sm ${circleColor}`}
                  >
                    {acct.name[0]}
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-semibold truncate">
                        {acct.name}
                      </span>
                      <Badge variant={styles.badge} className="text-[10px] px-1.5 py-0 gap-1">
                        <span className={`size-1.5 rounded-full ${styles.dot}`} />
                        {status}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-3 mt-0.5">
                      <span className="text-xs text-muted-foreground">
                        {acct.origin}
                      </span>
                      <span className="text-xs text-muted-foreground/60">
                        {acct.number}
                      </span>
                    </div>
                  </div>

                  {/* Balance */}
                  <div className="text-right shrink-0">
                    <p className="text-sm font-semibold">{acct.balance}</p>
                  </div>

                  {/* Action button */}
                  <div className="shrink-0">
                    {status === "Unlinked" && (
                      <Button
                        size="sm"
                        onClick={() => handleLink(acct.id, acct.name)}
                      >
                        <Link2 className="size-3.5 mr-1.5" />
                        Link
                      </Button>
                    )}
                    {status === "Linked" && (
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200"
                        onClick={() => handleUnlink(acct.id, acct.name)}
                      >
                        <Unlink className="size-3.5 mr-1.5" />
                        Unlink
                      </Button>
                    )}
                    {status === "Link Revoked" && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleRelink(acct.id, acct.name)}
                      >
                        <Link2 className="size-3.5 mr-1.5" />
                        Re-link
                      </Button>
                    )}
                    {status === "Link Requested" && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleCancelRequest(acct.id, acct.name)}
                      >
                        <X className="size-3.5 mr-1.5" />
                        Cancel Request
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}

/* ======================================================================== */
/*  2. AccountPermissionsModal                                               */
/* ======================================================================== */

const PERMISSION_OPTIONS = [
  "Full Control",
  "View + Transfer In",
  "View Only",
  "One-Way In",
] as const;

export function AccountPermissionsModal() {
  const modals = usePayMoStore((s) => s.modals);
  const closeModal = usePayMoStore((s) => s.closeModal);
  const linkedAccounts = usePayMoStore((s) => s.linkedAccounts);
  const updateLinkPermission = usePayMoStore((s) => s.updateLinkPermission);
  const updateLinkNotify = usePayMoStore((s) => s.updateLinkNotify);

  const open = modals.accountPermissions;

  /* Local permission state (optimistic) */
  const [localPermissions, setLocalPermissions] = useState<Record<number, string>>({});

  const getPermission = useCallback(
    (acct: (typeof linkedAccounts)[number]) => {
      return (localPermissions[acct.id] as typeof acct.permission) ?? acct.permission;
    },
    [localPermissions]
  );

  /* Check if any account has View Only */
  const hasViewOnly = useMemo(() => {
    return linkedAccounts.some((a) => getPermission(a) === "View Only");
  }, [linkedAccounts, getPermission]);

  const handlePermissionChange = useCallback(
    (id: number, permission: string) => {
      setLocalPermissions((prev) => ({ ...prev, [id]: permission }));
    },
    []
  );

  const handleSaveRow = useCallback(
    (id: number, name: string, permission: string) => {
      updateLinkPermission(id, permission);
      toast.success(`Permissions updated`, {
        description: `${name} set to "${permission}".`,
      });
    },
    [updateLinkPermission]
  );

  const handleSaveAll = useCallback(() => {
    linkedAccounts.forEach((acct) => {
      const perm = getPermission(acct);
      if (perm !== acct.permission) {
        updateLinkPermission(acct.id, perm);
      }
    });
    setLocalPermissions({});
    toast.success(`All permissions saved`, {
      description: `${linkedAccounts.length} account permissions updated.`,
    });
    closeModal("accountPermissions" as ModalId);
  }, [linkedAccounts, getPermission, updateLinkPermission, closeModal]);

  const handleClose = useCallback(() => {
    closeModal("accountPermissions" as ModalId);
    setLocalPermissions({});
  }, [closeModal]);

  return (
    <Dialog open={open} onOpenChange={(v) => !v && handleClose()}>
      <DialogContent className="max-w-2xl max-h-[85vh] flex flex-col gap-0 p-0 overflow-hidden">
        {/* Header */}
        <div className="px-6 pt-6 pb-4 space-y-3">
          <DialogHeader className="text-left space-y-1">
            <DialogTitle className="text-xl font-bold tracking-tight flex items-center gap-2">
              <ShieldAlert className="size-5 text-primary" />
              Account Permissions
            </DialogTitle>
            <DialogDescription className="text-sm text-muted-foreground">
              Control access levels and notification preferences for each linked account.
            </DialogDescription>
          </DialogHeader>

          {/* Warning alert for View Only accounts */}
          {hasViewOnly && (
            <div className="flex items-start gap-2.5 rounded-lg border border-amber-200 bg-amber-50 px-4 py-3">
              <AlertTriangle className="size-4 shrink-0 text-amber-600 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-amber-800">
                  Restricted Permission Detected
                </p>
                <p className="text-xs text-amber-700 mt-0.5">
                  One or more accounts are set to &ldquo;View Only&rdquo;. You won&apos;t
                  be able to initiate transfers or payments from these accounts.
                </p>
              </div>
            </div>
          )}

          <Separator />
        </div>

        {/* Scrollable list */}
        <ScrollArea className="flex-1 px-6">
          <div className="space-y-4 pb-4">
            {linkedAccounts.map((acct) => {
              const currentPermission = getPermission(acct);
              const circleColor = getColorForName(acct.name);

              return (
                <div
                  key={acct.id}
                  className="rounded-lg border p-4 space-y-4 transition-colors hover:bg-muted/20"
                >
                  {/* Row header */}
                  <div className="flex items-center gap-4">
                    <div
                      className={`flex size-10 shrink-0 items-center justify-center rounded-full text-white font-bold text-sm ${circleColor}`}
                    >
                      {acct.name[0]}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold truncate">
                          {acct.name}
                        </span>
                        <Badge
                          variant={
                            acct.status === "Active" ? "default" : "secondary"
                          }
                          className="text-[10px] px-1.5 py-0"
                        >
                          {acct.status}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-3 mt-0.5">
                        <span className="text-xs text-muted-foreground">
                          {acct.origin}
                        </span>
                        <span className="text-xs text-muted-foreground/60">
                          {acct.number}
                        </span>
                        <span className="text-xs font-medium">{acct.balance}</span>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Permission + notifications row */}
                  <div className="flex flex-col sm:flex-row sm:items-end gap-4">
                    {/* Permission select */}
                    <div className="flex-1 space-y-1.5">
                      <label className="text-xs font-medium text-muted-foreground">
                        Permission Level
                      </label>
                      <Select
                        value={currentPermission}
                        onValueChange={(v) =>
                          handlePermissionChange(acct.id, v)
                        }
                      >
                        <SelectTrigger className="w-full">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {PERMISSION_OPTIONS.map((p) => (
                            <SelectItem key={p} value={p}>
                              {p}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Notification toggles */}
                    <div className="space-y-1.5">
                      <label className="text-xs font-medium text-muted-foreground">
                        Notifications
                      </label>
                      <div className="flex items-center gap-4">
                        <label className="flex items-center gap-1.5 text-xs">
                          <Switch
                            checked={acct.notifyMobile}
                            onCheckedChange={() =>
                              updateLinkNotify(acct.id, "notifyMobile")
                            }
                          />
                          Mobile
                        </label>
                        <label className="flex items-center gap-1.5 text-xs">
                          <Switch
                            checked={acct.notifyEmail}
                            onCheckedChange={() =>
                              updateLinkNotify(acct.id, "notifyEmail")
                            }
                          />
                          Email
                        </label>
                        <label className="flex items-center gap-1.5 text-xs">
                          <Switch
                            checked={acct.notifyPush}
                            onCheckedChange={() =>
                              updateLinkNotify(acct.id, "notifyPush")
                            }
                          />
                          Push
                        </label>
                      </div>
                    </div>

                    {/* Save row */}
                    <Button
                      size="sm"
                      variant={
                        currentPermission !== acct.permission ? "default" : "outline"
                      }
                      onClick={() =>
                        handleSaveRow(acct.id, acct.name, currentPermission)
                      }
                      disabled={currentPermission === acct.permission}
                    >
                      <Save className="size-3.5 mr-1.5" />
                      Save
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </ScrollArea>

        {/* Footer */}
        <Separator />
        <DialogFooter className="px-6 py-4">
          <Button variant="outline" size="sm" onClick={handleClose}>
            Cancel
          </Button>
          <Button size="sm" onClick={handleSaveAll}>
            <Save className="size-3.5 mr-1.5" />
            Save All Permissions
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ======================================================================== */
/*  3. UnlinkAccountModal                                                    */
/* ======================================================================== */

export function UnlinkAccountModal() {
  const modals = usePayMoStore((s) => s.modals);
  const closeModal = usePayMoStore((s) => s.closeModal);
  const unlinkTargetId = usePayMoStore((s) => s.unlinkTargetId);
  const linkedAccounts = usePayMoStore((s) => s.linkedAccounts);
  const unlinkAccount = usePayMoStore((s) => s.unlinkAccount);
  const setUnlinkTargetId = usePayMoStore((s) => s.setUnlinkTargetId);

  const open = modals.unlinkAccount;
  const [pin, setPin] = useState("");
  const pinRefs = useRef<(HTMLInputElement | null)[]>([]);

  const target = linkedAccounts.find((a) => a.id === unlinkTargetId);

  /* Reset PIN when modal opens */
  useEffect(() => {
    if (open) {
      // eslint-disable-next-line react-hooks/set-state-in-effect -- intentional reset on modal open
      setPin("");
      setTimeout(() => pinRefs.current[0]?.focus(), 100);
    }
  }, [open]);

  const handlePinInput = useCallback(
    (index: number, value: string) => {
      const digit = value.replace(/\D/g, "").slice(-1);
      const chars = pin.split("");
      chars[index] = digit;
      const newPin = chars.join("");
      setPin(newPin);
      if (digit && index < 3) {
        pinRefs.current[index + 1]?.focus();
      }
    },
    [pin]
  );

  const handlePinKeyDown = useCallback(
    (index: number, e: React.KeyboardEvent) => {
      if (e.key === "Backspace" && !pin[index] && index > 0) {
        pinRefs.current[index - 1]?.focus();
      }
    },
    [pin]
  );

  const pinValid = pin.length === 4;

  const handleConfirm = useCallback(() => {
    if (!unlinkTargetId || !target) return;
    unlinkAccount(unlinkTargetId);
    toast.success(`Account unlinked`, {
      description: `${target.name} has been removed from this dashboard.`,
    });
    setUnlinkTargetId(null);
    closeModal("unlinkAccount" as ModalId);
  }, [unlinkTargetId, target, unlinkAccount, setUnlinkTargetId, closeModal]);

  const handleClose = useCallback(() => {
    closeModal("unlinkAccount" as ModalId);
    setUnlinkTargetId(null);
    setPin("");
  }, [closeModal, setUnlinkTargetId]);

  return (
    <Dialog open={open} onOpenChange={(v) => !v && handleClose()}>
      <DialogContent className="max-w-md flex flex-col gap-0 p-0 overflow-hidden">
        {/* Header */}
        <div className="px-6 pt-6 pb-4 space-y-4">
          <DialogHeader className="text-left space-y-2">
            <div className="flex items-center gap-3">
              <div className="flex size-10 items-center justify-center rounded-full bg-red-100">
                <AlertTriangle className="size-5 text-red-600" />
              </div>
              <div>
                <DialogTitle className="text-lg font-bold tracking-tight">
                  Unlink Account
                </DialogTitle>
                <DialogDescription className="text-sm">
                  This action requires confirmation.
                </DialogDescription>
              </div>
            </div>
          </DialogHeader>

          <Separator />

          {/* Warning text */}
          <div className="space-y-3">
            <p className="text-sm font-medium">
              Are you sure you want to unlink{" "}
              <span className="text-destructive font-bold">
                {target?.name ?? "this account"}
              </span>
              ?
            </p>

            {/* Account details card */}
            {target && (
              <div className="rounded-lg border bg-muted/30 p-4 space-y-2">
                <div className="flex items-center gap-3">
                  <div
                    className={`flex size-9 shrink-0 items-center justify-center rounded-full text-white font-bold text-xs ${getColorForName(target.name)}`}
                  >
                    {target.name[0]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold truncate">
                      {target.name}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {target.origin} &middot; {target.number}
                    </p>
                  </div>
                  <span className="text-sm font-bold">{target.balance}</span>
                </div>
              </div>
            )}

            {/* Warning details */}
            <div className="space-y-2 text-xs text-muted-foreground">
              <p>
                Once unlinked, this account will no longer be accessible from this
                dashboard. You can re-link it later.
              </p>
              <p className="text-red-600 font-medium">
                Any pending transactions from this account will be cancelled.
              </p>
            </div>

            {/* PIN input */}
            <div className="space-y-2">
              <label className="text-sm font-medium">
                Enter your PIN to confirm
              </label>
              <div className="flex items-center gap-3">
                {Array.from({ length: 4 }).map((_, i) => (
                  <Input
                    key={i}
                    ref={(el) => {
                      pinRefs.current[i] = el;
                    }}
                    type="password"
                    inputMode="numeric"
                    maxLength={1}
                    value={pin[i] ?? ""}
                    onChange={(e) => handlePinInput(i, e.target.value)}
                    onKeyDown={(e) => handlePinKeyDown(i, e)}
                    className={`h-12 w-12 text-center text-lg font-bold tracking-widest ${
                      pin[i]
                        ? "border-destructive ring-destructive/20 ring-2"
                        : ""
                    }`}
                    aria-label={`PIN digit ${i + 1}`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <Separator />
        <DialogFooter className="px-6 py-4 gap-2">
          <Button variant="outline" size="sm" onClick={handleClose}>
            Cancel
          </Button>
          <Button
            variant="destructive"
            size="sm"
            disabled={!pinValid}
            onClick={handleConfirm}
          >
            <Unlink className="size-3.5 mr-1.5" />
            Confirm Unlink
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// --- components/paymo/modals/relocation-modal.tsx ---

/* -------------------------------------------------------------------------- */
/*  Icon map                                                                   */
/* -------------------------------------------------------------------------- */

const RelocIconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Wallet,
  Briefcase,
  PiggyBank,
  Banknote,
  Bitcoin,
  TrendingUp,
};

function AccountIcon({
  name,
  bg,
  color,
  size = "sm",
}: {
  name: string;
  bg: string;
  color: string;
  size?: "sm" | "lg";
}) {
  const Icon = RelocIconMap[name] ?? Wallet;
  const cls = size === "lg" ? "h-12 w-12" : "h-9 w-9";
  const iconCls = size === "lg" ? "size-5" : "size-4";
  return (
    <div className={`flex ${cls} shrink-0 items-center justify-center rounded-lg ${bg}`}>
      <Icon className={`${iconCls} ${color}`} />
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*  Helpers                                                                    */
/* -------------------------------------------------------------------------- */

function parseBalance(balance: string): number {
  const cleaned = balance.replace(/[^0-9.]/g, "");
  return parseFloat(cleaned) || 0;
}

function formatNum(n: number): string {
  return n.toLocaleString("en-KE");
}

function generateRef(): string {
  return String(Math.floor(100000 + Math.random() * 900000));
}

function formatNow(): string {
  return new Date().toLocaleString("en-KE", {
    dateStyle: "medium",
    timeStyle: "short",
  });
}

const QUICK_AMOUNTS: { label: string; value: number }[] = [
  { label: "1K", value: 1000 },
  { label: "5K", value: 5000 },
  { label: "10K", value: 10000 },
  { label: "25K", value: 25000 },
  { label: "50K", value: 50000 },
  { label: "100K", value: 100000 },
];

const RELOC_TOTAL_STEPS = 8;

/* ====================================================================== */
/*  Component                                                              */
/* ====================================================================== */

export function MoneyRelocationModal() {
  /* ---- store ---- */
  const modals = usePayMoStore((s) => s.modals);
  const closeModal = usePayMoStore((s) => s.closeModal);
  const linkedAccounts = usePayMoStore((s) => s.linkedAccounts);
  const relocationSource = usePayMoStore((s) => s.relocationSource);
  const setRelocationSource = usePayMoStore((s) => s.setRelocationSource);
  const relocationDest = usePayMoStore((s) => s.relocationDest);
  const setRelocationDest = usePayMoStore((s) => s.setRelocationDest);
  const relocationAmount = usePayMoStore((s) => s.relocationAmount);
  const setRelocationAmount = usePayMoStore((s) => s.setRelocationAmount);
  const relocationStep = usePayMoStore((s) => s.relocationStep);
  const setRelocationStep = usePayMoStore((s) => s.setRelocationStep);

  const open = modals.moneyRelocation;

  /* ---- local state ---- */
  const [pin, setPin] = useState("");
  const pinRefEls = useRef<(HTMLInputElement | null)[]>([]);
  const [detailsChecked, setDetailsChecked] = useState(false);
  const [identityConfirmed, setIdentityConfirmed] = useState(false);
  const [irreversibleChecked, setIrreversibleChecked] = useState(false);
  const [verifiedChecked, setVerifiedChecked] = useState(false);
  const [authorizeChecked, setAuthorizeChecked] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showCancelDialog, setShowCancelDialog] = useState(false);
  const [refNumber] = useState(() => generateRef());

  /* ---- filtered accounts ---- */
  const activeAccounts = useMemo(
    () =>
      linkedAccounts.filter(
        (a) => a.status === "Active" && parseBalance(a.balance) > 0
      ),
    [linkedAccounts]
  );

  const destAccounts = useMemo(
    () => activeAccounts.filter((a) => String(a.id) !== relocationSource),
    [activeAccounts, relocationSource]
  );

  const sourceAccount = useMemo(
    () => linkedAccounts.find((a) => String(a.id) === relocationSource),
    [linkedAccounts, relocationSource]
  );

  const destAccount = useMemo(
    () => linkedAccounts.find((a) => String(a.id) === relocationDest),
    [linkedAccounts, relocationDest]
  );

  const sourceBalance = sourceAccount ? parseBalance(sourceAccount.balance) : 0;
  const destBalance = destAccount ? parseBalance(destAccount.balance) : 0;
  const amountNum = parseFloat(relocationAmount.replace(/,/g, "")) || 0;
  const remainingBalance = sourceBalance - amountNum;
  const isValidAmount = amountNum > 0 && amountNum <= sourceBalance;
  const isDestKES = destAccount?.balance.startsWith("KES") ?? false;
  const newSourceBalance = sourceBalance - amountNum;
  const newDestBalance = isDestKES ? destBalance + amountNum : destBalance;

  /* ---- reset on close ---- */
  const resetAll = useCallback(() => {
    setRelocationSource("");
    setRelocationDest("");
    setRelocationAmount("");
    setRelocationStep(0);
    setPin("");
    setDetailsChecked(false);
    setIdentityConfirmed(false);
    setIrreversibleChecked(false);
    setVerifiedChecked(false);
    setAuthorizeChecked(false);
    setIsProcessing(false);
    setShowCancelDialog(false);
  }, [
    setRelocationSource,
    setRelocationDest,
    setRelocationAmount,
    setRelocationStep,
  ]);

  const handleClose = useCallback(() => {
    if (relocationStep > 0 && relocationStep < 7) {
      setShowCancelDialog(true);
      return;
    }
    closeModal("moneyRelocation" as ModalId);
    setTimeout(resetAll, 200);
  }, [relocationStep, closeModal, resetAll]);

  const confirmCancel = useCallback(() => {
    setShowCancelDialog(false);
    closeModal("moneyRelocation" as ModalId);
    setTimeout(resetAll, 200);
    toast.info("Money relocation cancelled.");
  }, [closeModal, resetAll]);

  /* ---- PIN auto-focus ---- */
  useEffect(() => {
    if (relocationStep === 5) {
      const t = setTimeout(() => pinRefEls.current[0]?.focus(), 100);
      return () => clearTimeout(t);
    }
  }, [relocationStep]);

  const handlePinInput = useCallback(
    (index: number, value: string) => {
      const digit = value.replace(/\D/g, "").slice(-1);
      const chars = pin.split("");
      chars[index] = digit;
      const newPin = chars.join("");
      setPin(newPin);
      if (digit && index < 3) {
        pinRefEls.current[index + 1]?.focus();
      }
    },
    [pin]
  );

  const handlePinKeyDown = useCallback(
    (index: number, e: React.KeyboardEvent) => {
      if (e.key === "Backspace" && !pin[index] && index > 0) {
        pinRefEls.current[index - 1]?.focus();
      }
    },
    [pin]
  );

  /* ---- step navigation ---- */
  const goNext = useCallback(() => {
    if (relocationStep < 7) setRelocationStep(relocationStep + 1);
  }, [relocationStep, setRelocationStep]);

  const goBack = useCallback(() => {
    if (relocationStep > 0) setRelocationStep(relocationStep - 1);
  }, [relocationStep, setRelocationStep]);

  const handleContinue = useCallback(() => {
    if (relocationStep === 5) {
      setIsProcessing(true);
      setTimeout(() => {
        setIsProcessing(false);
        toast.success("PIN verified successfully");
        goNext();
      }, 1500);
      return;
    }
    if (relocationStep === 6) {
      setIsProcessing(true);
      setTimeout(() => {
        setIsProcessing(false);
        goNext();
      }, 2000);
      return;
    }
    goNext();
  }, [relocationStep, goNext]);

  /* ---- validation per step ---- */
  const canContinue = useMemo(() => {
    switch (relocationStep) {
      case 0:
        return !!relocationSource;
      case 1:
        return !!relocationDest;
      case 2:
        return isValidAmount;
      case 3:
        return detailsChecked;
      case 4:
        return identityConfirmed && irreversibleChecked;
      case 5:
        return pin.length === 4 && !isProcessing;
      case 6:
        return verifiedChecked && authorizeChecked && !isProcessing;
      default:
        return false;
    }
  }, [
    relocationStep,
    relocationSource,
    relocationDest,
    isValidAmount,
    detailsChecked,
    identityConfirmed,
    irreversibleChecked,
    pin,
    isProcessing,
    verifiedChecked,
    authorizeChecked,
  ]);

  const nextButtonLabel = useMemo(() => {
    switch (relocationStep) {
      case 0: return "Continue";
      case 1: return "Continue";
      case 2: return "Review Details";
      case 3: return "Continue";
      case 4: return "Continue to PIN";
      case 5: return isProcessing ? "Verifying…" : "Verify";
      case 6: return isProcessing ? "Processing…" : "Confirm & Process";
      default: return "Continue";
    }
  }, [relocationStep, isProcessing]);

  const progressPercent = ((relocationStep + 1) / RELOC_TOTAL_STEPS) * 100;

  /* ====================================================================== */
  /*  Render                                                                 */
  /* ====================================================================== */

  return (
    <>
      {/* Cancel confirmation dialog */}
      <Dialog
        open={showCancelDialog}
        onOpenChange={(v) => !v && setShowCancelDialog(false)}
      >
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-100">
                <AlertTriangle className="size-4 text-amber-600" />
              </div>
              Cancel Relocation?
            </DialogTitle>
            <DialogDescription>
              You have unsaved progress. All entered details will be lost if you
              cancel.
            </DialogDescription>
          </DialogHeader>
          <div className="flex gap-2 pt-2">
            <Button
              variant="outline"
              className="flex-1"
              onClick={() => setShowCancelDialog(false)}
            >
              Resume
            </Button>
            <Button
              variant="destructive"
              className="flex-1"
              onClick={confirmCancel}
            >
              Cancel Relocation
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Main wizard dialog */}
      <Dialog
        open={open}
        onOpenChange={(v) => !v && handleClose()}
      >
        <DialogContent
          className="max-w-2xl max-h-[92vh] flex flex-col gap-0 p-0 overflow-hidden"
          showCloseButton={false}
        >
          {/* HEADER */}
          <div className="px-6 pt-6 pb-4 space-y-4 shrink-0">
            <DialogHeader className="text-left space-y-1">
              <DialogTitle className="text-xl font-bold tracking-tight">
                Step {relocationStep + 1} of {RELOC_TOTAL_STEPS} —{" "}
                {relocationSteps[relocationStep]}
              </DialogTitle>
              <DialogDescription className="text-sm text-muted-foreground">
                {relocationStep === 0 &&
                  "Move funds between your linked PayMo accounts."}
                {relocationStep === 1 &&
                  "Choose where you want to send the funds."}
                {relocationStep === 2 &&
                  "Enter the amount you wish to relocate."}
                {relocationStep === 3 &&
                  "Verify the source and destination account details."}
                {relocationStep === 4 &&
                  "Confirm you are transferring to your own account."}
                {relocationStep === 5 &&
                  "Enter your PIN to authorize this transfer."}
                {relocationStep === 6 &&
                  "Review all details before confirming."}
                {relocationStep === 7 && "Your transfer has been processed."}
              </DialogDescription>
            </DialogHeader>

            {/* Progress bar */}
            <Progress value={progressPercent} className="h-1.5" />

            {/* Step stepper */}
            <div className="flex items-center gap-1 overflow-x-auto no-scrollbar">
              {relocationSteps.map((label, i) => {
                const isActive = i === relocationStep;
                const isDone = i < relocationStep;
                return (
                  <div
                    key={label}
                    className="flex items-center flex-1 min-w-0"
                  >
                    <div className="flex items-center gap-1.5 min-w-0">
                      <div
                        className={`shrink-0 flex items-center justify-center size-6 rounded-full text-xs font-semibold transition-colors ${
                          isActive
                            ? "bg-primary text-primary-foreground"
                            : isDone
                              ? "bg-emerald-500 text-white"
                              : "bg-muted text-muted-foreground"
                        }`}
                      >
                        {isDone ? (
                          <Check className="size-3" />
                        ) : (
                          <span>{i + 1}</span>
                        )}
                      </div>
                      <span
                        className={`truncate text-[10px] sm:text-xs font-medium transition-colors ${
                          isActive
                            ? "text-foreground"
                            : isDone
                              ? "text-emerald-600"
                              : "text-muted-foreground"
                        }`}
                      >
                        {label.length > 18
                          ? label.slice(0, 16) + "…"
                          : label}
                      </span>
                    </div>
                    {i < RELOC_TOTAL_STEPS - 1 && (
                      <div
                        className={`shrink-0 h-px flex-1 mx-1.5 ${
                          i < relocationStep
                            ? "bg-emerald-500"
                            : "bg-muted-foreground/20"
                        }`}
                      />
                    )}
                  </div>
                );
              })}
            </div>

            <Separator />
          </div>

          {/* SCROLLABLE CONTENT */}
          <div className="flex-1 overflow-y-auto px-6 pb-6">

            {/* STEP 0: Select Source Account */}
            {relocationStep === 0 && (
              <div className="space-y-4">
                <Alert>
                  <Info className="size-4" />
                  <AlertDescription>
                    Select the account you want to move funds <strong>FROM</strong>.
                  </AlertDescription>
                </Alert>

                <div className="grid gap-3">
                  {activeAccounts.map((acct) => {
                    const selected = String(acct.id) === relocationSource;
                    return (
                      <button
                        key={acct.id}
                        type="button"
                        onClick={() => setRelocationSource(String(acct.id))}
                        className={`flex items-center gap-4 rounded-xl border-2 p-4 text-left transition-all ${
                          selected
                            ? "border-primary bg-primary/5 ring-2 ring-primary/20"
                            : "border-border hover:border-muted-foreground/30 hover:bg-muted/40"
                        }`}
                      >
                        <AccountIcon
                          name={acct.icon}
                          bg={acct.bg}
                          color={acct.color}
                          size="lg"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-semibold">
                              {acct.name}
                            </span>
                            <Badge
                              variant={
                                acct.permission === "Full Control"
                                  ? "default"
                                  : "secondary"
                              }
                              className="text-[10px] px-1.5 py-0"
                            >
                              {acct.permission}
                            </Badge>
                          </div>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            {acct.origin} · {acct.number}
                          </p>
                          <p className="text-base font-bold mt-1 tabular-nums">
                            {acct.balance}
                          </p>
                        </div>
                        {selected && (
                          <CheckCircle2 className="size-5 text-primary shrink-0" />
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* STEP 1: Select Destination Account */}
            {relocationStep === 1 && (
              <div className="space-y-4">
                {sourceAccount && (
                  <div className="flex items-center gap-3 rounded-xl border bg-muted/40 px-4 py-3">
                    <AccountIcon
                      name={sourceAccount.icon}
                      bg={sourceAccount.bg}
                      color={sourceAccount.color}
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-muted-foreground">
                        Available from {sourceAccount.name}
                      </p>
                      <p className="text-sm font-bold tabular-nums">
                        {sourceAccount.balance}
                      </p>
                    </div>
                  </div>
                )}

                <Alert>
                  <Info className="size-4" />
                  <AlertDescription>
                    Select the account you want to send funds <strong>TO</strong>.
                  </AlertDescription>
                </Alert>

                <div className="grid gap-3">
                  {destAccounts.map((acct) => {
                    const selected = String(acct.id) === relocationDest;
                    return (
                      <button
                        key={acct.id}
                        type="button"
                        onClick={() => setRelocationDest(String(acct.id))}
                        className={`flex items-center gap-4 rounded-xl border-2 p-4 text-left transition-all ${
                          selected
                            ? "border-primary bg-primary/5 ring-2 ring-primary/20"
                            : "border-border hover:border-muted-foreground/30 hover:bg-muted/40"
                        }`}
                      >
                        <AccountIcon
                          name={acct.icon}
                          bg={acct.bg}
                          color={acct.color}
                          size="lg"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-semibold">
                              {acct.name}
                            </span>
                            <Badge
                              variant={
                                acct.permission === "Full Control"
                                  ? "default"
                                  : "secondary"
                              }
                              className="text-[10px] px-1.5 py-0"
                            >
                              {acct.permission}
                            </Badge>
                          </div>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            {acct.origin} · {acct.number}
                          </p>
                          <p className="text-base font-bold mt-1 tabular-nums">
                            {acct.balance}
                          </p>
                        </div>
                        {selected && (
                          <CheckCircle2 className="size-5 text-primary shrink-0" />
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* STEP 2: Enter Amount */}
            {relocationStep === 2 && (
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Transfer Amount
                  </label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-lg font-bold text-muted-foreground">
                      KES
                    </span>
                    <Input
                      type="text"
                      inputMode="numeric"
                      placeholder="0"
                      value={relocationAmount}
                      onChange={(e) => {
                        const raw = e.target.value.replace(/[^0-9]/g, "");
                        setRelocationAmount(
                          raw ? formatNum(parseInt(raw, 10)) : ""
                        );
                      }}
                      className="h-16 pl-16 pr-4 text-3xl font-bold tabular-nums"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Quick Select
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {QUICK_AMOUNTS.map((qa) => (
                      <button
                        key={qa.label}
                        type="button"
                        onClick={() => setRelocationAmount(formatNum(qa.value))}
                        className={`rounded-lg border px-4 py-2 text-sm font-semibold tabular-nums transition-colors ${
                          relocationAmount === formatNum(qa.value)
                            ? "border-primary bg-primary/10 text-primary"
                            : "border-border hover:border-primary hover:text-primary"
                        }`}
                      >
                        {qa.label}
                      </button>
                    ))}
                    <button
                      type="button"
                      onClick={() => setRelocationAmount(formatNum(sourceBalance))}
                      className={`rounded-lg border px-4 py-2 text-sm font-bold tabular-nums transition-colors ${
                        relocationAmount === formatNum(sourceBalance)
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-emerald-300 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 dark:border-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-400 dark:hover:bg-emerald-950"
                      }`}
                    >
                      ALL
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="rounded-xl border bg-muted/40 p-4">
                    <p className="text-xs text-muted-foreground">
                      Available Balance
                    </p>
                    <p className="text-lg font-bold tabular-nums mt-1">
                      KES {formatNum(sourceBalance)}
                    </p>
                  </div>
                  <div
                    className={`rounded-xl border p-4 ${
                      isValidAmount && amountNum > 0
                        ? "border-emerald-200 bg-emerald-50 dark:border-emerald-800 dark:bg-emerald-950/30"
                        : "border-border bg-muted/40"
                    }`}
                  >
                    <p className="text-xs text-muted-foreground">
                      Remaining Balance
                    </p>
                    <p
                      className={`text-lg font-bold tabular-nums mt-1 ${
                        isValidAmount && amountNum > 0
                          ? "text-emerald-700 dark:text-emerald-400"
                          : ""
                      }`}
                    >
                      KES {formatNum(Math.max(0, remainingBalance))}
                    </p>
                  </div>
                </div>

                {relocationAmount && !isValidAmount && (
                  <div className="flex items-center gap-2 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-800 dark:bg-red-950/30 dark:text-red-400">
                    <AlertTriangle className="size-4 shrink-0" />
                    {amountNum <= 0
                      ? "Amount must be greater than zero."
                      : "Amount exceeds available balance."}
                  </div>
                )}
              </div>
            )}

            {/* STEP 3: Review Account Details */}
            {relocationStep === 3 && sourceAccount && destAccount && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Source card */}
                  <div className="rounded-xl border-2 border-primary/30 bg-primary/5 p-5 space-y-3">
                    <div className="flex items-center justify-between">
                      <Badge className="bg-primary/10 text-primary border-primary/20 hover:bg-primary/15">
                        Source
                      </Badge>
                      <AccountIcon
                        name={sourceAccount.icon}
                        bg={sourceAccount.bg}
                        color={sourceAccount.color}
                      />
                    </div>
                    <div>
                      <p className="text-sm font-bold">{sourceAccount.name}</p>
                      <p className="text-xs text-muted-foreground">{sourceAccount.origin}</p>
                    </div>
                    <Separator />
                    <div className="space-y-1.5 text-xs">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Account Number</span>
                        <span className="font-medium">{sourceAccount.number}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Current Balance</span>
                        <span className="font-bold tabular-nums">{sourceAccount.balance}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Linked Since</span>
                        <span className="font-medium">{sourceAccount.linked}</span>
                      </div>
                    </div>
                  </div>

                  {/* Dest card */}
                  <div className="rounded-xl border-2 border-emerald-300 bg-emerald-50/50 dark:border-emerald-800 dark:bg-emerald-950/20 p-5 space-y-3">
                    <div className="flex items-center justify-between">
                      <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200 hover:bg-emerald-100 dark:bg-emerald-950/50 dark:text-emerald-400 dark:border-emerald-800">
                        Destination
                      </Badge>
                      <AccountIcon
                        name={destAccount.icon}
                        bg={destAccount.bg}
                        color={destAccount.color}
                      />
                    </div>
                    <div>
                      <p className="text-sm font-bold">{destAccount.name}</p>
                      <p className="text-xs text-muted-foreground">{destAccount.origin}</p>
                    </div>
                    <Separator />
                    <div className="space-y-1.5 text-xs">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Account Number</span>
                        <span className="font-medium">{destAccount.number}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Current Balance</span>
                        <span className="font-bold tabular-nums">{destAccount.balance}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Linked Since</span>
                        <span className="font-medium">{destAccount.linked}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Green arrow between cards */}
                <div className="flex items-center justify-center gap-3 py-1">
                  <span className="text-xs font-medium text-muted-foreground">
                    {sourceAccount.name}
                  </span>
                  <div className="flex items-center gap-1 rounded-full bg-emerald-100 px-3 py-1.5 dark:bg-emerald-950/50">
                    <ArrowRightLeft className="size-4 text-emerald-600 dark:text-emerald-400" />
                    <span className="text-xs font-bold text-emerald-700 dark:text-emerald-400 tabular-nums">
                      KES {relocationAmount}
                    </span>
                  </div>
                  <span className="text-xs font-medium text-muted-foreground">
                    {destAccount.name}
                  </span>
                </div>

                <label className="flex items-start gap-3 rounded-lg border p-4 cursor-pointer hover:bg-muted/40 transition-colors">
                  <Checkbox
                    checked={detailsChecked}
                    onCheckedChange={(v) => setDetailsChecked(!!v)}
                    className="mt-0.5"
                  />
                  <span className="text-sm font-medium">All details correct?</span>
                </label>
              </div>
            )}

            {/* STEP 4: Confirm Recipient Identity */}
            {relocationStep === 4 && destAccount && (
              <div className="space-y-5">
                <Alert>
                  <ShieldCheck className="size-4" />
                  <AlertTitle>Self-Transfer</AlertTitle>
                  <AlertDescription>
                    You are transferring to your own linked account.
                  </AlertDescription>
                </Alert>

                <div className="rounded-xl border bg-muted/40 p-5 space-y-4">
                  <div className="flex items-center gap-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-lg font-bold text-primary">
                      AK
                    </div>
                    <div>
                      <p className="text-sm font-bold">Amina Grace Kamau</p>
                      <p className="text-xs text-muted-foreground">
                        Account Holder (You)
                      </p>
                    </div>
                  </div>

                  <Separator />

                  <div className="flex items-center gap-2 rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 dark:border-amber-800 dark:bg-amber-950/30">
                    <AlertTriangle className="size-4 shrink-0 text-amber-600 dark:text-amber-400" />
                    <p className="text-sm text-amber-800 dark:text-amber-300">
                      Verify the destination account number matches:{" "}
                      <strong className="font-mono">{destAccount.number}</strong>
                    </p>
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="flex items-start gap-3 rounded-lg border p-4 cursor-pointer hover:bg-muted/40 transition-colors">
                    <Checkbox
                      checked={identityConfirmed}
                      onCheckedChange={(v) => setIdentityConfirmed(!!v)}
                      className="mt-0.5"
                    />
                    <span className="text-sm font-medium">I confirm this is my account</span>
                  </label>

                  <label className="flex items-start gap-3 rounded-lg border p-4 cursor-pointer hover:bg-muted/40 transition-colors">
                    <Checkbox
                      checked={irreversibleChecked}
                      onCheckedChange={(v) => setIrreversibleChecked(!!v)}
                      className="mt-0.5"
                    />
                    <span className="text-sm font-medium">I understand this transfer is irreversible once confirmed</span>
                  </label>
                </div>
              </div>
            )}

            {/* STEP 5: Security Verification (PIN) */}
            {relocationStep === 5 && (
              <div className="space-y-6">
                <Alert variant="destructive">
                  <ShieldAlert className="size-4" />
                  <AlertTitle>PIN Verification Required</AlertTitle>
                  <AlertDescription>
                    This action requires PIN verification for security.
                  </AlertDescription>
                </Alert>

                <div className="flex flex-col items-center gap-6 py-4">
                  <div className="flex items-center gap-3">
                    {Array.from({ length: 4 }).map((_, i) => (
                      <Input
                        key={i}
                        ref={(el) => {
                          pinRefEls.current[i] = el;
                        }}
                        type="password"
                        inputMode="numeric"
                        maxLength={1}
                        value={pin[i] ?? ""}
                        onChange={(e) => handlePinInput(i, e.target.value)}
                        onKeyDown={(e) => handlePinKeyDown(i, e)}
                        className={`h-16 w-16 text-center text-2xl font-bold tracking-widest ${
                          pin[i] ? "border-primary ring-primary/20 ring-2" : ""
                        }`}
                        disabled={isProcessing}
                        aria-label={`PIN digit ${i + 1}`}
                      />
                    ))}
                  </div>

                  {isProcessing && (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <div className="size-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />
                      Verifying PIN…
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2 rounded-lg border bg-muted/40 px-4 py-3 text-xs text-muted-foreground">
                  <FileText className="size-4 shrink-0" />
                  <span>This transfer will be logged for audit purposes.</span>
                </div>
              </div>
            )}

            {/* STEP 6: Final Review & Confirmation */}
            {relocationStep === 6 && sourceAccount && destAccount && (
              <div className="space-y-5">
                <div className="rounded-xl border-2 border-primary/20 bg-gradient-to-b from-primary/5 to-transparent p-5 space-y-4">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="size-5 text-primary" />
                    <h3 className="text-sm font-bold">Transfer Summary</h3>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">
                        From (Source)
                      </p>
                      <p className="text-sm font-semibold">{sourceAccount.name}</p>
                      <p className="text-xs text-muted-foreground">{sourceAccount.number}</p>
                      <p className="text-xs font-bold tabular-nums">{sourceAccount.balance}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">
                        To (Destination)
                      </p>
                      <p className="text-sm font-semibold">{destAccount.name}</p>
                      <p className="text-xs text-muted-foreground">{destAccount.number}</p>
                    </div>
                  </div>

                  <Separator />

                  <div className="text-center py-2">
                    <p className="text-xs text-muted-foreground uppercase tracking-wider font-medium">
                      Transfer Amount
                    </p>
                    <p className="text-3xl font-bold tabular-nums mt-1">
                      KES {relocationAmount}
                    </p>
                  </div>

                  <Separator />

                  <div className="space-y-2 text-sm">
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Transfer fee (internal)</span>
                      <span className="font-medium">KES 0</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Total</span>
                      <span className="font-bold text-lg tabular-nums">KES {relocationAmount}</span>
                    </div>
                  </div>

                  <Separator />

                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Clock className="size-3.5" />
                    <span>Initiated: {formatNow()}</span>
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="flex items-start gap-3 rounded-lg border p-4 cursor-pointer hover:bg-muted/40 transition-colors">
                    <Checkbox
                      checked={verifiedChecked}
                      onCheckedChange={(v) => setVerifiedChecked(!!v)}
                      className="mt-0.5"
                    />
                    <span className="text-sm font-medium">I have verified all details above</span>
                  </label>

                  <label className="flex items-start gap-3 rounded-lg border p-4 cursor-pointer hover:bg-muted/40 transition-colors">
                    <Checkbox
                      checked={authorizeChecked}
                      onCheckedChange={(v) => setAuthorizeChecked(!!v)}
                      className="mt-0.5"
                    />
                    <span className="text-sm font-medium">I authorize this fund relocation</span>
                  </label>
                </div>
              </div>
            )}

            {/* STEP 7: Processing & Receipt */}
            {relocationStep === 7 && sourceAccount && destAccount && (
              <div className="space-y-6">
                {/* Success animation */}
                <div className="flex flex-col items-center gap-4 py-4">
                  <div className="relative">
                    <div className="flex h-20 w-20 items-center justify-center rounded-full bg-emerald-500 animate-in zoom-in-50 duration-500">
                      <Check className="size-10 text-white" strokeWidth={3} />
                    </div>
                    <div className="absolute inset-0 h-20 w-20 rounded-full bg-emerald-400/30 animate-ping" />
                  </div>
                  <div className="text-center space-y-1">
                    <h2 className="text-xl font-bold text-emerald-700 dark:text-emerald-400">
                      Transfer Successful!
                    </h2>
                    <p className="text-sm text-muted-foreground">
                      KES {relocationAmount} from {sourceAccount.name} to{" "}
                      {destAccount.name}
                    </p>
                  </div>
                </div>

                <Separator />

                {/* Receipt details */}
                <div className="rounded-xl border bg-muted/40 p-5 space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">Reference Number</span>
                    <span className="text-sm font-bold font-mono text-primary">
                      RLC-2025-{refNumber}
                    </span>
                  </div>

                  <Separator />

                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Transfer Amount</span>
                      <span className="font-bold tabular-nums">KES {relocationAmount}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Fee</span>
                      <span className="font-medium">KES 0</span>
                    </div>

                    <Separator />

                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">New {sourceAccount.name} Balance</span>
                      <span className="font-bold tabular-nums">
                        {sourceAccount.balance.startsWith("KES")
                          ? `KES ${formatNum(newSourceBalance)}`
                          : sourceAccount.balance}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">New {destAccount.name} Balance</span>
                      <span className="font-bold tabular-nums text-emerald-600">
                        {isDestKES
                          ? `KES ${formatNum(newDestBalance)}`
                          : destAccount.balance}
                      </span>
                    </div>
                  </div>

                  <Separator />

                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Clock className="size-3.5" />
                    <span>{formatNow()}</span>
                  </div>
                </div>

                {/* Action buttons */}
                <div className="grid grid-cols-2 gap-3">
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() =>
                      toast.success("Receipt downloaded successfully")
                    }
                  >
                    <Download className="size-4 mr-2" />
                    Download Receipt
                  </Button>
                  <Button
                    className="w-full"
                    onClick={() => {
                      closeModal("moneyRelocation" as ModalId);
                      setTimeout(resetAll, 200);
                      toast.success("Money relocation completed!");
                    }}
                  >
                    Done
                  </Button>
                </div>
              </div>
            )}
          </div>

          {/* FOOTER */}
          {relocationStep < 7 && (
            <>
              <Separator />
              <DialogFooter className="px-6 py-4 gap-2 sm:justify-between">
                <div>
                  {relocationStep > 0 ? (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={goBack}
                      disabled={isProcessing}
                    >
                      <ArrowLeft className="size-3.5 mr-1.5" />
                      Back
                    </Button>
                  ) : (
                    <Button variant="ghost" size="sm" onClick={handleClose}>
                      Cancel
                    </Button>
                  )}
                </div>

                <Button
                  size="sm"
                  disabled={!canContinue}
                  onClick={handleContinue}
                >
                  {isProcessing && relocationStep >= 5 ? (
                    <>
                      <div className="size-3.5 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent mr-1.5" />
                      {nextButtonLabel}
                    </>
                  ) : (
                    <>
                      {nextButtonLabel}
                      {!isProcessing && (
                        <ArrowRight className="size-3.5 ml-1.5" />
                      )}
                    </>
                  )}
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}

// --- components/paymo/modals/security-modals.tsx ---

/* -------------------------------------------------------------------------- */
/*  Helpers                                                                    */
/* -------------------------------------------------------------------------- */

function DeviceIcon({ device, className }: { device: string; className?: string }) {
  if (device.startsWith("iPhone") || device.startsWith("iPad")) {
    return <Smartphone className={className} />;
  }
  return <Laptop className={className} />;
}

function SessStatusBadge({ status }: { status: "Current" | "Active" | "New" }) {
  const variants: Record<string, string> = {
    Current: "bg-emerald-100 text-emerald-700 border-emerald-200",
    Active: "bg-blue-100 text-blue-700 border-blue-200",
    New: "bg-amber-100 text-amber-700 border-amber-200",
  };
  return (
    <Badge
      variant="outline"
      className={`text-[10px] font-medium ${variants[status]}`}
    >
      {status}
    </Badge>
  );
}

function LogStatusBadge({ status }: { status: AccessLog["status"] }) {
  const variants: Record<string, string> = {
    Success: "bg-emerald-100 text-emerald-700 border-emerald-200",
    Review: "bg-amber-100 text-amber-700 border-amber-200",
    Revoked: "bg-red-100 text-red-700 border-red-200",
  };
  return (
    <Badge
      variant="outline"
      className={`text-[10px] font-medium ${variants[status]}`}
    >
      {status}
    </Badge>
  );
}

/* ========================================================================== */
/*  1. SessionManagementModal                                                 */
/* ========================================================================== */

export function SessionManagementModal() {
  const open = usePayMoStore((s) => s.modals.sessionManagement);
  const close = usePayMoStore((s) => s.closeModal);

  const handleRevoke = (device: string) => {
    toast.success(`Session on ${device} has been revoked successfully.`);
  };

  const handleRevokeAll = () => {
    const otherCount = sessions.filter((s) => !s.current).length;
    toast.success(`${otherCount} other session${otherCount !== 1 ? "s" : ""} have been revoked.`);
    close("sessionManagement");
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && close("sessionManagement")}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-100">
              <ShieldCheck className="size-4 text-emerald-600" />
            </div>
            Session Management
          </DialogTitle>
          <DialogDescription>
            Monitor and control active sessions across your devices.
          </DialogDescription>
        </DialogHeader>

        {/* Summary Strip */}
        <div className="flex items-center gap-2 rounded-lg border bg-muted/40 px-4 py-2.5">
          <span className="relative flex h-2.5 w-2.5">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
            <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-500" />
          </span>
          <span className="text-sm font-medium">{sessions.length} active sessions</span>
        </div>

        {/* Session Cards */}
        <div className="space-y-3">
          {sessions.map((session, idx) => (
            <div
              key={idx}
              className={`rounded-xl border p-4 transition-colors hover:bg-muted/30 ${
                session.current ? "border-l-4 border-l-emerald-500" : ""
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3 min-w-0">
                  <div
                    className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg ${
                      session.current ? "bg-emerald-100" : "bg-muted"
                    }`}
                  >
                    <DeviceIcon
                      device={session.device}
                      className={`size-4 ${
                        session.current ? "text-emerald-600" : "text-muted-foreground"
                      }`}
                    />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="text-sm font-semibold">{session.device}</p>
                      <SessStatusBadge status={session.status} />
                    </div>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      {session.detail}
                    </p>
                    <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <MapPin className="size-3" />
                        {session.location}
                      </span>
                      <span>{session.ip}</span>
                      <span className="flex items-center gap-1">
                        <Clock className="size-3" />
                        {session.lastActive}
                      </span>
                    </div>
                  </div>
                </div>

                {!session.current && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="shrink-0 text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700 dark:border-red-800 dark:hover:bg-red-950/40"
                    onClick={() => handleRevoke(session.device)}
                  >
                    <LogOut className="size-3.5" />
                    Revoke
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>

        <Separator />

        <DialogFooter>
          <Button variant="outline" onClick={() => close("sessionManagement")}>
            Close
          </Button>
          <Button
            variant="destructive"
            onClick={handleRevokeAll}
          >
            <LogOut className="size-4" />
            Revoke All Other Sessions
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ========================================================================== */
/*  2. AccessLogsModal                                                        */
/* ========================================================================== */

type LogFilter = "All" | "Success" | "Review" | "Revoked";

const logFilters: LogFilter[] = ["All", "Success", "Review", "Revoked"];

export function AccessLogsModal() {
  const open = usePayMoStore((s) => s.modals.accessLogs);
  const close = usePayMoStore((s) => s.closeModal);
  const [filter, setFilter] = useState<LogFilter>("All");

  const filtered =
    filter === "All"
      ? accessLogs
      : accessLogs.filter((log) => log.status === filter);

  return (
    <Dialog open={open} onOpenChange={(v) => !v && close("accessLogs")}>
      <DialogContent className="sm:max-w-lg max-h-[85vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-sky-100">
              <ScrollText className="size-4 text-sky-600" />
            </div>
            Security &amp; Access Logs
          </DialogTitle>
          <DialogDescription>
            Chronological record of security events and access activity.
          </DialogDescription>
        </DialogHeader>

        {/* Filter Tabs */}
        <div className="flex gap-1.5 rounded-lg border bg-muted/40 p-1">
          {logFilters.map((f) => (
            <button
              key={f}
              type="button"
              onClick={() => setFilter(f)}
              className={`flex-1 rounded-md px-3 py-1.5 text-xs font-medium transition-all ${
                filter === f
                  ? "bg-background text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {f}
            </button>
          ))}
        </div>

        {/* Timeline Logs */}
        <ScrollArea className="flex-1 -mx-6 px-6">
          {filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <ScrollText className="size-10 text-muted-foreground/30" />
              <p className="mt-3 text-sm font-medium text-muted-foreground">
                No logs found
              </p>
              <p className="mt-1 text-xs text-muted-foreground/70">
                No entries match the &ldquo;{filter}&rdquo; filter.
              </p>
            </div>
          ) : (
            <div className="relative space-y-0">
              {/* Vertical line */}
              <div className="absolute left-[59px] top-2 bottom-2 w-px bg-border" />

              {filtered.map((log, idx) => (
                <div key={idx} className="relative flex gap-4 py-3">
                  {/* Dot on timeline */}
                  <div className="relative z-10 mt-1.5 flex h-3 w-3 shrink-0 items-center justify-center">
                    <CircleDot
                      className={`size-3 ${
                        log.variant === "success"
                          ? "text-emerald-500"
                          : log.variant === "warning"
                            ? "text-amber-500"
                            : "text-red-500"
                      }`}
                    />
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0 rounded-lg border bg-muted/20 px-4 py-3 transition-colors hover:bg-muted/40">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="text-sm font-semibold">{log.action}</p>
                        <div className="mt-1.5 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                          <Badge variant="outline" className="text-[10px] font-medium">
                            {log.dash}
                          </Badge>
                          <span>{log.device}</span>
                          <span>{log.ip}</span>
                        </div>
                      </div>
                      <div className="shrink-0 flex flex-col items-end gap-1.5">
                        <LogStatusBadge status={log.status} />
                        <span className="text-[11px] text-muted-foreground whitespace-nowrap">
                          {log.date}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>

        <Separator />

        <DialogFooter>
          <Button variant="outline" onClick={() => close("accessLogs")}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ========================================================================== */
/*  3. NotificationSettingsModal                                              */
/* ========================================================================== */

export function NotificationSettingsModal() {
  const open = usePayMoStore((s) => s.modals.notificationSettings);
  const close = usePayMoStore((s) => s.closeModal);
  const linkedAccounts = usePayMoStore((s) => s.linkedAccounts);
  const updateLinkNotify = usePayMoStore((s) => s.updateLinkNotify);

  const [masterEnabled, setMasterEnabled] = useState(true);
  const [quietHours, setQuietHours] = useState(false);
  const [quietStart, setQuietStart] = useState("22:00");
  const [quietEnd, setQuietEnd] = useState("07:00");

  const handleSave = () => {
    toast.success("Notification preferences saved successfully.");
    close("notificationSettings");
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && close("notificationSettings")}>
      <DialogContent className="sm:max-w-lg max-h-[85vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-purple-100">
              <Bell className="size-4 text-purple-600" />
            </div>
            Notification Preferences
          </DialogTitle>
          <DialogDescription>
            Control how and when you receive alerts for each linked account.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 flex-1 overflow-y-auto paymo-scroll -mx-6 px-6">
          {/* Master Toggle */}
          <div className="flex items-center justify-between rounded-xl border bg-muted/40 px-4 py-3">
            <div className="flex items-center gap-3">
              {masterEnabled ? (
                <Bell className="size-4 text-purple-600" />
              ) : (
                <BellOff className="size-4 text-muted-foreground" />
              )}
              <div>
                <p className="text-sm font-medium">Master notification switch</p>
                <p className="text-[11px] text-muted-foreground">
                  Enable or disable all notifications at once
                </p>
              </div>
            </div>
            <Switch
              checked={masterEnabled}
              onCheckedChange={setMasterEnabled}
            />
          </div>

          {/* Quiet Hours */}
          <div className="rounded-xl border px-4 py-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Moon className="size-4 text-indigo-500" />
                <div>
                  <p className="text-sm font-medium">Quiet hours</p>
                  <p className="text-[11px] text-muted-foreground">
                    Silence notifications during set hours
                  </p>
                </div>
              </div>
              <Switch
                checked={quietHours}
                onCheckedChange={setQuietHours}
              />
            </div>
            {quietHours && (
              <div className="mt-3 flex items-center gap-3 pl-7">
                <Input
                  type="time"
                  value={quietStart}
                  onChange={(e) => setQuietStart(e.target.value)}
                  className="h-8 w-28 text-xs"
                />
                <span className="text-xs text-muted-foreground">to</span>
                <Input
                  type="time"
                  value={quietEnd}
                  onChange={(e) => setQuietEnd(e.target.value)}
                  className="h-8 w-28 text-xs"
                />
              </div>
            )}
          </div>

          <Separator />

          {/* Per-Account Toggles */}
          <div className="space-y-3">
            {linkedAccounts.map((account) => (
              <div
                key={account.id}
                className="rounded-xl border p-4 transition-colors hover:bg-muted/30"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-semibold">{account.name}</p>
                    <p className="text-[11px] text-muted-foreground">
                      {account.origin} &middot; {account.number}
                    </p>
                  </div>
                  <Badge
                    variant="outline"
                    className={`text-[10px] font-medium ${
                      account.status === "Active"
                        ? "border-emerald-200 text-emerald-700"
                        : "border-amber-200 text-amber-700"
                    }`}
                  >
                    {account.status}
                  </Badge>
                </div>

                <div className="mt-3 grid grid-cols-3 gap-3">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <Switch
                      checked={account.notifyMobile}
                      onCheckedChange={() =>
                        updateLinkNotify(account.id, "notifyMobile")
                      }
                      className="scale-90"
                    />
                    <div className="flex flex-col">
                      <span className="text-xs font-medium">Mobile SMS</span>
                      <Phone className="size-3 text-muted-foreground mt-0.5" />
                    </div>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <Switch
                      checked={account.notifyEmail}
                      onCheckedChange={() =>
                        updateLinkNotify(account.id, "notifyEmail")
                      }
                      className="scale-90"
                    />
                    <div className="flex flex-col">
                      <span className="text-xs font-medium">Email</span>
                      <Mail className="size-3 text-muted-foreground mt-0.5" />
                    </div>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <Switch
                      checked={account.notifyPush}
                      onCheckedChange={() =>
                        updateLinkNotify(account.id, "notifyPush")
                      }
                      className="scale-90"
                    />
                    <div className="flex flex-col">
                      <span className="text-xs font-medium">Push</span>
                      <MessageSquare className="size-3 text-muted-foreground mt-0.5" />
                    </div>
                  </label>
                </div>
              </div>
            ))}
          </div>
        </div>

        <Separator />

        <DialogFooter>
          <Button variant="outline" onClick={() => close("notificationSettings")}>
            Cancel
          </Button>
          <Button onClick={handleSave}>
            <Bell className="size-4" />
            Save Preferences
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ========================================================================== */
/*  4. AutoRulesModal                                                         */
/* ========================================================================== */

export function AutoRulesModal() {
  const open = usePayMoStore((s) => s.modals.autoRules);
  const close = usePayMoStore((s) => s.closeModal);
  const rulesEnabled = usePayMoStore((s) => s.rulesEnabled);
  const toggleRule = usePayMoStore((s) => s.toggleRule);

  const handleSave = () => {
    toast.success("Automated rules saved. Changes take effect within 60 seconds.");
    close("autoRules");
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && close("autoRules")}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-100">
              <SlidersHorizontal className="size-4 text-amber-600" />
            </div>
            Automated Rules &amp; Limits
          </DialogTitle>
          <DialogDescription>
            Configure automatic fund movement rules between your linked accounts.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          {autoRules.map((rule) => {
            const enabled = rulesEnabled[rule.id] ?? false;
            return (
              <div
                key={rule.id}
                className="rounded-xl border p-4 transition-colors hover:bg-muted/30"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3 min-w-0">
                    <div className="mt-0.5">
                      <span
                        className={`inline-block h-2.5 w-2.5 rounded-full ${
                          enabled ? "bg-emerald-500" : "bg-muted-foreground/30"
                        }`}
                      />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="text-sm font-semibold">{rule.name}</p>
                        <Badge
                          variant="outline"
                          className={`text-[10px] font-medium ${rule.tagColor}`}
                        >
                          {rule.tag}
                        </Badge>
                      </div>
                      <p className="mt-1 text-xs text-muted-foreground leading-relaxed">
                        {rule.desc}
                      </p>
                    </div>
                  </div>
                  <Switch
                    checked={enabled}
                    onCheckedChange={() => toggleRule(rule.id)}
                    className="shrink-0"
                  />
                </div>
              </div>
            );
          })}
        </div>

        {/* Info Box */}
        <Alert className="border-sky-200 bg-sky-50/50 dark:border-sky-800 dark:bg-sky-950/20">
          <Info className="size-4 text-sky-600" />
          <AlertDescription className="text-xs text-sky-700 dark:text-sky-400">
            Rules are evaluated in real-time. Changes take effect within 60 seconds.
          </AlertDescription>
        </Alert>

        <DialogFooter>
          <Button variant="outline" onClick={() => close("autoRules")}>
            Cancel
          </Button>
          <Button onClick={handleSave}>
            <SlidersHorizontal className="size-4" />
            Save Rules
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// --- components/paymo/modals/revoke-modal.tsx ---

export function RevokeAccessModal() {
  const { modals, closeModal } = usePayMoStore();
  const [selectedDash, setSelectedDash] = useState<string>('');
  const [pin, setPin] = useState('');
  const [processing, setProcessing] = useState(false);
  const [confirmed, setConfirmed] = useState(false);

  const pinRefs = [useState<HTMLInputElement | null>(null)[0], useState<HTMLInputElement | null>(null)[0], useState<HTMLInputElement | null>(null)[0], useState<HTMLInputElement | null>(null)[0]];

  const activeDashboards = dashboards.filter((d) => d.status !== 'Not Activated');

  const handlePinInput = useCallback((
    index: number,
    value: string,
    e: React.ChangeEvent<HTMLInputElement>,
  ) => {
    if (!/\d/.test(value) && value !== '') return;
    const newPin = pin.split('').map((c, i) => (i === index ? value : c)).join('');
    setPin(newPin);
    if (value && index < 3) {
      pinRefs[index + 1]?.focus();
    }
  }, [pin, pinRefs]);

  const handlePinKeyDown = useCallback((
    index: number,
    e: React.KeyboardEvent<HTMLInputElement>,
  ) => {
    if (e.key === 'Backspace' && !pin[index] && index > 0) {
      pinRefs[index - 1]?.focus();
    }
  }, [pin, pinRefs]);

  const handleRevoke = () => {
    setProcessing(true);
    setTimeout(() => {
      setProcessing(false);
      setConfirmed(true);
      toast.success(`${selectedDash} access has been revoked successfully.`);
    }, 2000);
  };

  const handleClose = () => {
    closeModal('revokeAccess');
    setTimeout(() => {
      setSelectedDash('');
      setPin('');
      setProcessing(false);
      setConfirmed(false);
    }, 200);
  };

  const selected = activeDashboards.find((d) => d.name === selectedDash);

  return (
    <Dialog
      open={modals.revokeAccess}
      onOpenChange={(open) => { if (!open) handleClose(); }}
    >
      <DialogContent className="sm:max-w-lg gap-0 p-0">
        <DialogHeader className="p-6 pb-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-red-100 text-red-600">
              <ShieldAlert className="h-5 w-5" />
            </div>
            <div>
              <DialogTitle>Revoke Dashboard Access</DialogTitle>
              <DialogDescription>
                Permanently deactivate a dashboard and unlink all associated accounts.
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        {!confirmed ? (
          <>
            <div className="px-6 space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Select Dashboard</label>
                <div className="grid gap-2">
                  {activeDashboards.map((dash) => (
                    <button
                      key={dash.id}
                      onClick={() => setSelectedDash(dash.name)}
                      className={`flex items-center gap-3 p-3 rounded-xl border-2 text-left transition-all cursor-pointer ${
                        selectedDash === dash.name
                          ? 'border-red-300 bg-red-50'
                          : 'border-transparent bg-muted/50 hover:bg-muted'
                      }`}
                    >
                      <div className={`flex h-9 w-9 items-center justify-center rounded-lg ${dash.bg} ${dash.color}`}>
                        <Smartphone className="h-4 w-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-medium text-sm">{dash.name}</div>
                        <div className="text-xs text-muted-foreground">{dash.desc}</div>
                      </div>
                      <Badge
                        variant={dash.variant === 'danger' ? 'destructive' : 'outline'}
                        className={dash.variant === 'success' ? 'border-emerald-300 text-emerald-700' : ''}
                      >
                        {dash.status}
                      </Badge>
                    </button>
                  ))}
                </div>
              </div>

              {selectedDash && (
                <>
                  <Alert variant="destructive">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertDescription>
                      <strong>Warning:</strong> Revoking {selectedDash} will immediately unlink all
                      accounts associated with this dashboard. Any pending transactions will be cancelled.
                      You can re-activate later by going through the full activation flow again.
                    </AlertDescription>
                  </Alert>

                  {selected && selected.variant === 'danger' && (
                    <div className="flex items-center gap-2 p-3 rounded-lg bg-red-50 border border-red-200">
                      <AlertTriangle className="h-4 w-4 text-red-600 shrink-0" />
                      <span className="text-sm text-red-700">
                        {selected.name} is currently suspended. Revoking will fully remove it.
                      </span>
                    </div>
                  )}

                  <div>
                    <label className="text-sm font-medium mb-2 block">
                      Enter PIN to Confirm
                    </label>
                    <div className="flex gap-3 justify-center">
                      {[0, 1, 2, 3].map((i) => (
                        <Input
                          key={i}
                          ref={pinRefs[i]}
                          type="password"
                          maxLength={1}
                          value={pin[i] || ''}
                          onChange={(e) => handlePinInput(i, e.target.value, e)}
                          onKeyDown={(e) => handlePinKeyDown(i, e)}
                          className="w-14 h-14 text-center text-xl font-bold"
                        />
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>

            <DialogFooter className="p-6 pt-4 flex justify-between">
              <Button variant="outline" onClick={handleClose}>Cancel</Button>
              <Button
                variant="destructive"
                disabled={!selectedDash || pin.length < 4 || processing}
                onClick={handleRevoke}
              >
                {processing ? (
                  <><Loader2 className="h-4 w-4 animate-spin mr-2" /> Revoking...</>
                ) : (
                  <><ShieldAlert className="h-4 w-4 mr-2" /> Revoke Access</>
                )}
              </Button>
            </DialogFooter>
          </>
        ) : (
          <div className="p-6 text-center space-y-4">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100">
              <ShieldAlert className="h-8 w-8 text-emerald-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold">Access Revoked</h3>
              <p className="text-sm text-muted-foreground mt-1">
                {selectedDash} has been deactivated. All linked accounts have been unlinked.
              </p>
            </div>
            <Button onClick={handleClose} className="w-full">
              Done
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

// --- components/paymo/modals/tour-modal.tsx ---

const stepIcons = [
  Briefcase,
  Wallet,
  Zap,
  PiggyBank,
  Briefcase,
  ArrowRight,
  TrendingUp,
  ShieldCheck,
];

export function TourGuideModal() {
  const { modals, closeModal } = usePayMoStore();
  const [current, setCurrent] = useState(0);
  const isLast = current === tourSteps.length - 1;

  const progress = ((current + 1) / tourSteps.length) * 100;
  const Icon = stepIcons[current] || Map;

  const handleClose = () => {
    closeModal('tourGuide');
    setCurrent(0);
  };

  return (
    <Dialog
      open={modals.tourGuide}
      onOpenChange={(open) => { if (!open) handleClose(); }}
    >
      <DialogContent className="sm:max-w-lg gap-0 p-0">
        <DialogHeader className="p-6 pb-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-100 text-indigo-600">
              <Map className="h-5 w-5" />
            </div>
            <div>
              <DialogTitle>Dashboard Tour Guide</DialogTitle>
              <DialogDescription>
                Step {current + 1} of {tourSteps.length}
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <div className="px-6 space-y-4">
          <Progress value={progress} className="h-1.5" />

          <div className="flex justify-center gap-2">
            {tourSteps.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrent(i)}
                className={`h-2.5 w-2.5 rounded-full transition-all cursor-pointer ${
                  i === current
                    ? 'bg-primary w-6'
                    : i < current
                      ? 'bg-primary/40'
                      : 'bg-muted'
                }`}
              />
            ))}
          </div>

          <div className="flex flex-col items-center py-6 gap-4">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 text-primary">
              <Icon className="h-8 w-8" />
            </div>
            <div className="text-center max-w-sm">
              <h3 className="text-lg font-semibold">{tourSteps[current].title}</h3>
              <p className="text-sm text-muted-foreground mt-2 leading-relaxed">
                {tourSteps[current].desc}
              </p>
            </div>
          </div>
        </div>

        <DialogFooter className="p-6 pt-4 flex justify-between">
 <Button variant="outline" onClick={() => setCurrent((p) => Math.max(0, p - 1))} disabled={current === 0}>
            <ArrowLeft className="h-4 w-4 mr-1.5" /> Back
          </Button>
          {isLast ? (
            <Button onClick={handleClose}>
              <CheckCircle2 className="h-4 w-4 mr-1.5" /> Got It
            </Button>
          ) : (
            <Button onClick={() => setCurrent((p) => p + 1)}>
              Next <ArrowRight className="h-4 w-4 ml-1.5" />
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// --- components/paymo/modals/dashboards-modal.tsx ---

const DashIconMap: Record<string, React.ElementType> = {
  ArrowLeftRight,
  Briefcase,
  Zap,
  Code,
  Banknote,
  PiggyBank,
  Bitcoin,
  CreditCard,
  ShieldPlus,
  Building2,
};

function StatusBadge({ variant, label }: { variant: string; label: string }) {
  const cls: Record<string, string> = {
    success: 'bg-emerald-100 text-emerald-700 border-emerald-200',
    warning: 'bg-amber-100 text-amber-700 border-amber-200',
    danger: 'bg-red-100 text-red-700 border-red-200',
    grey: 'bg-muted text-muted-foreground border-border',
  };
  const Icon: Record<string, React.ElementType> = {
    success: CheckCircle2,
    warning: Clock,
    danger: XCircle,
    grey: Lock,
  };
  const Comp = Icon[variant] || Clock;
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium border ${cls[variant] || cls.grey}`}>
      <Comp className="h-3 w-3" /> {label}
    </span>
  );
}

export function DashboardsModal() {
  const { modals, closeModal, openModal } = usePayMoStore();

  const activeCount = dashboards.filter((d) => d.status === 'Active').length;

  const handleDashClick = (dash: (typeof dashboards)[number]) => {
    if (dash.status === 'Active') {
      openModal('walletHealth');
    } else if (dash.status === 'Suspended') {
      openModal('revokeAccess');
    } else {
      closeModal('dashboards');
      setTimeout(() => openModal('activateDashboard'), 200);
    }
  };

  return (
    <Dialog
      open={modals.dashboards}
      onOpenChange={(open) => { if (!open) closeModal('dashboards'); }}
    >
      <DialogContent className="sm:max-w-2xl gap-0 p-0">
        <DialogHeader className="p-6 pb-4">
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle>Your Dashboards</DialogTitle>
              <DialogDescription className="mt-1">
                Manage and activate your PayMo service dashboards.
              </DialogDescription>
            </div>
            <Badge variant="outline" className="text-xs">
              {activeCount} of {dashboards.length} active
            </Badge>
          </div>
        </DialogHeader>

        <div className="px-6 pb-6">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {dashboards.map((dash) => {
              const Icon = DashIconMap[dash.icon] || Briefcase;
              return (
                <button
                  key={dash.id}
                  onClick={() => handleDashClick(dash)}
                  className="flex flex-col items-center gap-2 p-4 rounded-xl border bg-card hover:bg-accent/50 transition-all text-center cursor-pointer group"
                >
                  <div className={`flex h-11 w-11 items-center justify-center rounded-xl ${dash.bg} ${dash.color} group-hover:scale-110 transition-transform`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <div className="font-semibold text-sm leading-tight">{dash.name}</div>
                  <div className="text-[11px] text-muted-foreground leading-tight">{dash.desc}</div>
                  <StatusBadge variant={dash.variant} label={dash.status} />
                  {dash.last !== '—' && (
                    <div className="text-[10px] text-muted-foreground">Last: {dash.last}</div>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// --- components/paymo/account-flow-chart.tsx ---

const FlowIconMap: Record<string, React.ElementType> = {
  Wallet,
  Briefcase,
  PiggyBank,
  Banknote,
  Bitcoin,
  TrendingUp,
};

const permissionLabels: Record<string, { short: string; color: string; glow: string; desc: string }> = {
  'Full Control': {
    short: 'Full Control',
    color: '#10b981',
    glow: 'rgba(16,185,129,0.35)',
    desc: 'Full access to balance & transact freely between dashboards',
  },
  'View + Transfer In': {
    short: 'Receive Only',
    color: '#f59e0b',
    glow: 'rgba(245,158,11,0.35)',
    desc: 'Can receive funds into this dashboard from the wallet',
  },
  'View Only': {
    short: 'View Only',
    color: '#6b7280',
    glow: 'rgba(107,114,128,0.3)',
    desc: 'Balance visible but no transactions allowed',
  },
  'One-Way In': {
    short: 'One-Way In',
    color: '#3b82f6',
    glow: 'rgba(59,130,246,0.35)',
    desc: 'Funds flow in one direction only into this account',
  },
};

/* ------------------------------------------------------------------ */
/*  Node positions — arranged in a radial layout around center          */
/* ------------------------------------------------------------------ */
interface NodePosition {
  id: number;
  x: number;
  y: number;
}

function useNodePositions(count: number, containerWidth: number, containerHeight: number) {
  return useMemo(() => {
    const cx = containerWidth / 2;
    const cy = containerHeight / 2;
    const radiusX = Math.min(cx * 0.75, 260);
    const radiusY = Math.min(cy * 0.7, 180);

    const positions: NodePosition[] = [];
    for (let i = 0; i < count; i++) {
      const angle = (2 * Math.PI * i) / count - Math.PI / 2;
      positions.push({
        id: i + 1,
        x: cx + radiusX * Math.cos(angle),
        y: cy + radiusY * Math.sin(angle),
      });
    }
    return positions;
  }, [count, containerWidth, containerHeight]);
}

/* ------------------------------------------------------------------ */
/*  Animated path with flowing dots                                    */
/* ------------------------------------------------------------------ */
function AnimatedPath({
  fromX,
  fromY,
  toX,
  toY,
  color,
  glow,
  permission,
  status,
}: {
  fromX: number;
  fromY: number;
  toX: number;
  toY: number;
  color: string;
  glow: string;
  permission: string;
  status: string;
}) {
  const isActive = status === 'Active';

  /* Control point for curved path */
  const midX = (fromX + toX) / 2;
  const midY = (fromY + toY) / 2;
  const dx = toX - fromX;
  const dy = toY - fromY;
  const cx1 = midX - dy * 0.15;
  const cy1 = midY + dx * 0.15;
  const pathD = `M ${fromX} ${fromY} Q ${cx1} ${cy1} ${toX} ${toY}`;

  const info = permissionLabels[permission] || permissionLabels['View Only'];

  return (
    <g>
      {/* Glow layer */}
      <motion.path
        d={pathD}
        fill="none"
        stroke={glow}
        strokeWidth={isActive ? 6 : 2}
        strokeLinecap="round"
        initial={{ pathLength: 0, opacity: 0 }}
        animate={{ pathLength: 1, opacity: isActive ? 0.6 : 0.15 }}
        transition={{ duration: 1.2, ease: 'easeInOut' }}
      />
      {/* Main line */}
      <motion.path
        d={pathD}
        fill="none"
        stroke={color}
        strokeWidth={isActive ? 2 : 1}
        strokeDasharray={isActive ? 'none' : '6 4'}
        strokeLinecap="round"
        initial={{ pathLength: 0, opacity: 0 }}
        animate={{ pathLength: 1, opacity: isActive ? 0.9 : 0.3 }}
        transition={{ duration: 1.2, ease: 'easeInOut', delay: 0.2 }}
      />
      {/* Flowing dot (only for active) */}
      {isActive && (
        <motion.circle
          r={3}
          fill={color}
          filter={`url(#glow-${color.replace('#', '')})`}
        >
          <animateMotion
            dur={isActive ? '3s' : '0s'}
            repeatCount="indefinite"
            path={pathD}
          />
        </motion.circle>
      )}
      {/* Arrow at destination */}
      <motion.circle
        cx={toX}
        cy={toY}
        r={4}
        fill={color}
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 0.8 }}
        transition={{ delay: 1, duration: 0.3 }}
      />
      {/* Permission label on path */}
      <motion.g
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2, duration: 0.5 }}
      >
        <rect
          x={cx1 - info.short.length * 3.5 - 6}
          y={cy1 - 10}
          width={info.short.length * 7 + 12}
          height={20}
          rx={6}
          fill="rgba(10,15,28,0.9)"
          stroke={color}
          strokeWidth={0.5}
          strokeOpacity={0.4}
        />
        <text
          x={cx1}
          y={cy1 + 1}
          textAnchor="middle"
          dominantBaseline="central"
          fill={color}
          fontSize={9}
          fontWeight={600}
          fontFamily="system-ui, sans-serif"
        >
          {info.short}
        </text>
      </motion.g>
    </g>
  );
}

/* ------------------------------------------------------------------ */
/*  Account node                                                       */
/* ------------------------------------------------------------------ */
function AccountNode({
  account,
  x,
  y,
  index,
}: {
  account: ActiveLink;
  x: number;
  y: number;
  index: number;
}) {
  const Icon = FlowIconMap[account.icon] || Wallet;
  const info = permissionLabels[account.permission] || permissionLabels['View Only'];
  const isActive = account.status === 'Active';

  return (
    <motion.g
      initial={{ opacity: 0, scale: 0 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: 0.3 + index * 0.15, type: 'spring', stiffness: 200 }}
    >
      {/* Node background */}
      <motion.rect
        x={x - 52}
        y={y - 38}
        width={104}
        height={76}
        rx={14}
        fill={isActive ? 'rgba(16,24,40,0.95)' : 'rgba(16,24,40,0.7)'}
        stroke={info.color}
        strokeWidth={1}
        strokeOpacity={isActive ? 0.6 : 0.25}
        whileHover={{
          strokeOpacity: 1,
          scale: 1.08,
          transition: { duration: 0.2 },
        }}
      />
      {/* Status dot */}
      <circle
        cx={x + 40}
        cy={y - 26}
        r={4}
        fill={isActive ? '#10b981' : '#f59e0b'}
      >
        {isActive && (
          <animate
            attributeName="opacity"
            values="1;0.4;1"
            dur="2s"
            repeatCount="indefinite"
          />
        )}
      </circle>
      {/* Icon */}
      <foreignObject x={x - 12} y={y - 24} width={24} height={24}>
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: '100%',
            height: '100%',
          }}
        >
          <Icon size={16} style={{ color: info.color }} />
        </div>
      </foreignObject>
      {/* Name */}
      <text
        x={x}
        y={y + 8}
        textAnchor="middle"
        fill="#e5e7eb"
        fontSize={10}
        fontWeight={600}
        fontFamily="system-ui, sans-serif"
      >
        {account.name.length > 16 ? account.name.slice(0, 14) + '..' : account.name}
      </text>
      {/* Balance */}
      <text
        x={x}
        y={y + 22}
        textAnchor="middle"
        fill={info.color}
        fontSize={10}
        fontWeight={700}
        fontFamily="system-ui, sans-serif"
      >
        {account.balance}
      </text>
      {/* Origin label */}
      <text
        x={x}
        y={y + 34}
        textAnchor="middle"
        fill="#6b7280"
        fontSize={8}
        fontFamily="system-ui, sans-serif"
      >
        {account.origin}
      </text>
    </motion.g>
  );
}

/* ------------------------------------------------------------------ */
/*  Center wallet node                                                 */
/* ------------------------------------------------------------------ */
function CenterNode({ x, y }: { x: number; y: number }) {
  return (
    <motion.g
      initial={{ opacity: 0, scale: 0 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ type: 'spring', stiffness: 150, delay: 0.1 }}
    >
      {/* Outer glow pulse */}
      <motion.circle
        cx={x}
        cy={y}
        r={56}
        fill="none"
        stroke="rgba(16,185,129,0.2)"
        strokeWidth={1}
        animate={{ r: [56, 64, 56], opacity: [0.3, 0.1, 0.3] }}
        transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
      />
      {/* Main circle */}
      <circle
        cx={x}
        cy={y}
        r={48}
        fill="rgba(6,78,59,0.9)"
        stroke="#10b981"
        strokeWidth={2}
      />
      {/* Inner circle */}
      <circle
        cx={x}
        cy={y}
        r={38}
        fill="none"
        stroke="rgba(16,185,129,0.3)"
        strokeWidth={1}
      />
      {/* Wallet icon */}
      <foreignObject x={x - 16} y={y - 26} width={32} height={32}>
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: '100%',
            height: '100%',
          }}
        >
          <Wallet size={28} color="#10b981" />
        </div>
      </foreignObject>
      {/* Labels */}
      <text
        x={x}
        y={y + 18}
        textAnchor="middle"
        fill="#d1fae5"
        fontSize={10}
        fontWeight={700}
        fontFamily="system-ui, sans-serif"
      >
        Primary Wallet
      </text>
      <text
        x={x}
        y={y + 30}
        textAnchor="middle"
        fill="#6ee7b7"
        fontSize={9}
        fontWeight={500}
        fontFamily="system-ui, sans-serif"
      >
        PM-4521-8830-1024
      </text>
    </motion.g>
  );
}

/* ------------------------------------------------------------------ */
/*  Main FlowChart component                                           */
/* ------------------------------------------------------------------ */
export function AccountFlowChart() {
  const { linkedAccounts, openModal } = usePayMoStore();
  const [dimensions, setDimensions] = useState({ width: 700, height: 440 });
  const [hoveredId, setHoveredId] = useState<number | null>(null);
  const containerRef = useCallback((node: HTMLDivElement | null) => {
    if (!node) return;
    const observer = new ResizeObserver((entries) => {
      const { width } = entries[0].contentRect;
      setDimensions({
        width: Math.max(width, 400),
        height: Math.max(Math.min(width * 0.63, 440), 320),
      });
    });
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  const positions = useNodePositions(
    linkedAccounts.length,
    dimensions.width,
    dimensions.height,
  );

  const cx = dimensions.width / 2;
  const cy = dimensions.height / 2;

  const hoveredAccount = linkedAccounts.find((a) => a.id === hoveredId);
  const hoveredInfo = hoveredAccount
    ? permissionLabels[hoveredAccount.permission]
    : null;

  return (
    <div className="w-full">
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-lg font-semibold">Account Flow</h2>
        <div className="flex gap-2">
          <button
            onClick={() => openModal('accountPermissions')}
            className="text-xs px-3 py-1.5 rounded-lg border bg-card hover:bg-accent/50 transition-colors font-medium cursor-pointer"
          >
            <Eye className="h-3 w-3 inline mr-1" /> Permissions
          </button>
          <button
            onClick={() => openModal('linkAccount')}
            className="text-xs px-3 py-1.5 rounded-lg border bg-card hover:bg-accent/50 transition-colors font-medium cursor-pointer"
          >
            <ArrowRight className="h-3 w-3 inline mr-1" /> Manage Links
          </button>
        </div>
      </div>

      {/* Flow chart container */}
      <div
        ref={containerRef}
        className="w-full rounded-2xl overflow-hidden border"
        style={{ background: 'linear-gradient(135deg, #070b14 0%, #0a1628 50%, #0d1117 100%)' }}
      >
        <svg
          width="100%"
          height={dimensions.height}
          viewBox={`0 0 ${dimensions.width} ${dimensions.height}`}
          className="w-full"
          style={{ display: 'block' }}
        >
          <defs>
            {/* Glow filters for each color */}
            {['10b981', 'f59e0b', '6b7280', '3b82f6'].map((hex) => (
              <filter key={hex} id={`glow-${hex}`} x="-50%" y="-50%" width="200%" height="200%">
                <feGaussianBlur stdDeviation={3} result="blur" />
                <feFlood floodColor={`#${hex}`} floodOpacity={0.6} result="color" />
                <feComposite in="color" in2="blur" operator="in" result="glow" />
                <feMerge>
                  <feMergeNode in="glow" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            ))}
          </defs>

          {/* Grid pattern (subtle) */}
          <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(255,255,255,0.03)" strokeWidth={0.5} />
          </pattern>
          <rect width="100%" height="100%" fill="url(#grid)" />

          {/* Connections from center to each node */}
          {positions.map((pos, i) => {
            const account = linkedAccounts[i];
            if (!account) return null;
            const info = permissionLabels[account.permission] || permissionLabels['View Only'];
            return (
              <AnimatedPath
                key={account.id}
                fromX={cx}
                fromY={cy}
                toX={pos.x}
                toY={pos.y}
                color={info.color}
                glow={info.glow}
                permission={account.permission}
                status={account.status}
              />
            );
          })}

          {/* Center node */}
          <CenterNode x={cx} y={cy} />

          {/* Account nodes */}
          {positions.map((pos, i) => {
            const account = linkedAccounts[i];
            if (!account) return null;
            return (
              <g
                key={account.id}
                onMouseEnter={() => setHoveredId(account.id)}
                onMouseLeave={() => setHoveredId(null)}
                style={{ cursor: 'pointer' }}
              >
                <AccountNode
                  account={account}
                  x={pos.x}
                  y={pos.y}
                  index={i}
                />
              </g>
            );
          })}

          {/* Hovered tooltip */}
          <AnimatePresence>
            {hoveredAccount && hoveredInfo && (
              <motion.g
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 5 }}
                transition={{ duration: 0.15 }}
              >
                <rect
                  x={cx - 130}
                  y={dimensions.height - 44}
                  width={260}
                  height={32}
                  rx={8}
                  fill="rgba(16,24,40,0.95)"
                  stroke={hoveredInfo.color}
                  strokeWidth={0.5}
                  strokeOpacity={0.5}
                />
                <text
                  x={cx}
                  y={dimensions.height - 24}
                  textAnchor="middle"
                  fill="#d1d5db"
                  fontSize={10}
                  fontFamily="system-ui, sans-serif"
                >
                  {hoveredInfo.desc}
                </text>
              </motion.g>
            )}
          </AnimatePresence>
        </svg>
      </div>

      {/* Legend below chart */}
      <div className="flex flex-wrap gap-3 mt-3 px-1">
        {Object.entries(permissionLabels).map(([key, val]) => (
          <div key={key} className="flex items-center gap-1.5">
            <div
              className="w-2.5 h-2.5 rounded-full"
              style={{ backgroundColor: val.color, boxShadow: `0 0 6px ${val.glow}` }}
            />
            <span className="text-[11px] text-muted-foreground">{val.short}</span>
          </div>
        ))}
        <div className="flex items-center gap-1.5 ml-auto">
          <CircleDot className="h-3 w-3 text-emerald-500" />
          <span className="text-[11px] text-muted-foreground">Active</span>
          <div className="w-2.5 h-2.5 rounded-full bg-amber-500 ml-2" />
          <span className="text-[11px] text-muted-foreground">Paused</span>
        </div>
      </div>
    </div>
  );
}

// --- components/paymo/paymo-page.tsx ---

export function PayMoPage() {
  const { openModal } = usePayMoStore();
  const [copied, setCopied] = useState(false);

  const copyAccountNumber = useCallback(() => {
    navigator.clipboard.writeText(wallet.accountNumber);
    setCopied(true);
    toast.success('Account number copied to clipboard');
    setTimeout(() => setCopied(false), 2000);
  }, []);

  const quickActions: {
    id: ModalId;
    icon: React.ElementType;
    label: string;
    desc: string;
    color: string;
    bg: string;
  }[] = [
    { id: 'walletDetail', icon: Wallet, label: 'My Wallet', desc: 'View full wallet details, QR code & download statement', color: 'text-emerald-600', bg: 'bg-emerald-100' },
    { id: 'linkAccount', icon: Link2, label: 'Link Account', desc: 'Connect accounts from other dashboards to this one', color: 'text-purple-600', bg: 'bg-purple-100' },
    { id: 'activateDashboard', icon: Sparkles, label: 'Activate Dashboard', desc: 'Activate new dashboards with consent & PIN verification', color: 'text-amber-600', bg: 'bg-amber-100' },
    { id: 'dashboards', icon: LayoutGrid, label: 'All Dashboards', desc: 'View and manage all 10 PayMo service dashboards', color: 'text-sky-600', bg: 'bg-sky-100' },
    { id: 'notificationSettings', icon: Bell, label: 'Notifications', desc: 'Configure SMS, email & push notification preferences', color: 'text-violet-600', bg: 'bg-violet-100' },
    { id: 'sessionManagement', icon: MonitorSmartphone, label: 'Sessions', desc: 'View and manage active login sessions across devices', color: 'text-teal-600', bg: 'bg-teal-100' },
    { id: 'revokeAccess', icon: ShieldAlert, label: 'Revoke Access', desc: 'Deactivate a dashboard and unlink all its accounts', color: 'text-red-600', bg: 'bg-red-100' },
    { id: 'autoRules', icon: Route, label: 'Auto Rules', desc: 'Set up automated fund movement rules & limits', color: 'text-orange-600', bg: 'bg-orange-100' },
    { id: 'moneyRelocation', icon: Map, label: 'Money Relocation', desc: 'Safely move funds between linked accounts (8-step wizard)', color: 'text-teal-600', bg: 'bg-teal-100' },
    { id: 'tourGuide', icon: Route, label: 'Tour Guide', desc: 'Take a guided tour of the current dashboard sections', color: 'text-indigo-600', bg: 'bg-indigo-100' },
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8 space-y-6">
        {/* ---- Breadcrumb & Title ---- */}
        <div>
          <nav className="text-sm text-muted-foreground mb-1">
            <a href="#" className="hover:text-foreground transition-colors">Home</a>
            <span className="mx-1.5">/</span>
            <a href="#" className="hover:text-foreground transition-colors">Account</a>
            <span className="mx-1.5">/</span>
            <span className="font-medium text-foreground">Wallet Hub</span>
          </nav>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
            Wallet Activation & Cross-Dashboard Hub
          </h1>
          <p className="text-muted-foreground mt-1 max-w-2xl text-sm">
            Your central gateway for activating dashboards, linking accounts, managing permissions, and securely moving funds across PayMo.
          </p>
        </div>

        {/* ---- Primary Wallet Card ---- */}
        <div className="wallet-gradient rounded-2xl p-5 sm:p-6 text-white relative overflow-hidden">
          <div className="absolute -top-20 -right-20 w-64 h-64 rounded-full bg-white/5" />
          <div className="absolute -bottom-16 -left-16 w-48 h-48 rounded-full bg-white/5" />
          <div className="relative flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-4">
                <div className="flex items-center gap-1.5 font-bold tracking-wider text-sm">
                  <Wallet className="h-4 w-4" /> PAYMO WALLET
                </div>
                <span className="text-[11px] font-semibold px-2.5 py-0.5 rounded-full bg-white/15">
                  <CheckCircle2 className="inline h-3 w-3 mr-0.5" /> {wallet.status}
                </span>
              </div>
              <div className="text-xs uppercase tracking-widest text-white/70 mb-1">Account Number</div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-xl sm:text-2xl font-bold tracking-wider">
                  {wallet.accountNumber}
                </span>
                <button
                  onClick={copyAccountNumber}
                  className="p-1.5 rounded-lg bg-white/15 hover:bg-white/25 border border-white/20 transition-all cursor-pointer"
                  title="Copy account number"
                >
                  {copied ? <CheckCircle2 className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                </button>
                <button
                  onClick={() => openModal('shareQR')}
                  className="p-1.5 rounded-lg bg-white/15 hover:bg-white/25 border border-white/20 transition-all cursor-pointer"
                  title="Show QR code"
                >
                  <QrCode className="h-3.5 w-3.5" />
                </button>
              </div>
              <div className="text-xs text-white/70 mt-2">
                {wallet.holder} &bull; Premium &bull; {wallet.walletId}
              </div>
            </div>
            <div className="text-left sm:text-right">
              <div className="text-xs uppercase tracking-widest text-white/70 mb-1">Available Balance</div>
              <div className="font-mono text-3xl sm:text-4xl font-bold">
                {wallet.balance}
              </div>
              <div className="flex items-center gap-1.5 mt-2 justify-start sm:justify-end flex-wrap">
                {wallet.currencies.map((c) => (
                  <span key={c} className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-white/15">
                    {c}
                  </span>
                ))}
              </div>
            </div>
          </div>
          {/* Quick stats bar */}
          <div className="relative mt-4 pt-4 border-t border-white/15 grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <div className="text-[10px] uppercase tracking-wider text-white/60">Linked Dashboards</div>
              <div className="font-semibold text-sm mt-0.5">{wallet.linkedDashboards} active</div>
            </div>
            <div>
              <div className="text-[10px] uppercase tracking-wider text-white/60">Pending In</div>
              <div className="font-semibold text-sm mt-0.5 text-emerald-300">{wallet.pendingIncoming}</div>
            </div>
            <div>
              <div className="text-[10px] uppercase tracking-wider text-white/60">Pending Out</div>
              <div className="font-semibold text-sm mt-0.5 text-amber-300">{wallet.pendingOutgoing}</div>
            </div>
            <div>
              <div className="text-[10px] uppercase tracking-wider text-white/60">Consolidated</div>
              <div className="font-semibold text-sm mt-0.5">{wallet.consolidated}</div>
            </div>
          </div>
        </div>

        {/* ---- Quick Actions Grid ---- */}
        <div>
          <h2 className="text-lg font-semibold mb-3">Quick Actions</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {quickActions.map((action) => {
              const Icon = action.icon;
              return (
                <button
                  key={action.id}
                  onClick={() => openModal(action.id)}
                  className="flex items-start gap-2.5 p-3 rounded-xl border bg-card hover:bg-accent/50 transition-all text-left group cursor-pointer"
                >
                  <div className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${action.bg} ${action.color} group-hover:scale-105 transition-transform`}>
                    <Icon className="h-4 w-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-xs leading-tight">{action.label}</div>
                    <div className="text-[10px] text-muted-foreground mt-0.5 line-clamp-2 leading-tight">{action.desc}</div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* ---- Animated Account Flow Chart ---- */}
        <AccountFlowChart />
      </div>
    </div>
  );
}