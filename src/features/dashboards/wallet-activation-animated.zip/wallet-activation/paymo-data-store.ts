/** PayMo Data + Types + Store. Deps: zustand */

/* ============================================================================ * PayMo Platform – Mock Data & Types * All types and mock data for the Wallet Activation & Cross-Dashboard Hub. * ============================================================================ */ export interface Wallet {  accountNumber: string;  walletId: string;  holder: string;  initials: string;  tier: string;  balance: string;  status: string;  opened: string;  age: string;  currencies: string[];  linkedDashboards: number;  pendingIncoming: string;  pendingOutgoing: string;  consolidated: string;  security: { pin: boolean; biometric: boolean; twoFA: boolean; sessions: number }; } export interface HealthFeedItem {  icon: string;  bg: string;  color: string;  title: string;  desc: string;  time: string;  amount: string; } export interface Dashboard {  id: number;  name: string;  icon: string;  bg: string;  color: string;  desc: string;  status: 'Active' | 'Activation Pending' | 'Not Activated' | 'Suspended';  variant: 'success' | 'warning' | 'grey' | 'danger';  last: string;  action: string;  notify: boolean; } export interface ConsentItem {  name: string;  desc: string;  optional?: boolean; } export interface LinkableAccount {  id: number;  name: string;  origin: string;  icon: string;  bg: string;  color: string;  number: string;  balance: string;  status: 'Linked' | 'Link Revoked' | 'Link Requested' | 'Unlinked';  variant: 'success' | 'danger' | 'warning' | 'grey'; } export interface ActiveLink {  id: number;  name: string;  origin: string;  icon: string;  bg: string;  color: string;  number: string;  linked: string;  balance: string;  status: 'Active' | 'Paused';  permission: 'Full Control' | 'View + Transfer In' | 'View Only' | 'One-Way In';  full: boolean;  notifyMobile: boolean;  notifyEmail: boolean;  notifyPush: boolean; } export interface AutoRule {  id: number;  name: string;  desc: string;  tag: string;  tagColor: string;  active: boolean; } export interface Session {  device: string;  detail: string;  location: string;  dash: string;  lastActive: string;  ip: string;  status: 'Current' | 'Active' | 'New';  current: boolean; } export interface AccessLog {  date: string;  action: string;  dash: string;  ip: string;  device: string;  status: 'Success' | 'Review' | 'Revoked';  variant: 'success' | 'warning' | 'danger'; } /* ---- Mock Data ---- */ export const wallet: Wallet = {  accountNumber: 'PM-4521-8830-1024',  walletId: 'WLT-8H2K-9XQ4',  holder: 'Amina Grace Kamau',  initials: 'AK',  tier: 'Premium',  balance: 'KES 1,284,300',  status: 'Active',  opened: '12 January 2023',  age: '2 years 7 months',  currencies: ['KES', 'USD', 'EUR', 'GBP'],  linkedDashboards: 6,  pendingIncoming: 'KES 45,000',  pendingOutgoing: 'KES 12,500',  consolidated: 'KES 2,412,800',  security: { pin: true, biometric: true, twoFA: true, sessions: 4 }, }; export const healthFeed: HealthFeedItem[] = [  { icon: 'ArrowDownLeft', bg: 'bg-emerald-100', color: 'text-emerald-600', title: 'Received KES 125,000', desc: 'PayMo KES Wallet → Transaction Hub', time: 'Today, 14:22', amount: '+KES 125,000' },  { icon: 'ArrowUpRight', bg: 'bg-amber-100', color: 'text-amber-600', title: 'Sent KES 25,000', desc: 'Business Float → Utilities Hub', time: '25 Jun, 09:12', amount: '-KES 25,000' },  { icon: 'PiggyBank', bg: 'bg-purple-100', color: 'text-purple-600', title: 'Auto-sweep KES 180,000', desc: 'Business Float → Savings Jar', time: '24 Jun, 11:45', amount: '-KES 180,000' }, ]; export const dashboards: Dashboard[] = [  { id: 1, name: 'Transaction Hub', icon: 'ArrowLeftRight', bg: 'bg-emerald-100', color: 'text-emerald-600', desc: 'Payments, P2P & remittances', status: 'Active', variant: 'success', last: 'Today, 14:22', action: 'Enter', notify: false },  { id: 2, name: 'Business Portal', icon: 'Briefcase', bg: 'bg-purple-100', color: 'text-purple-600', desc: 'Merchant payments, collections & payroll', status: 'Activation Pending', variant: 'warning', last: '—', action: 'Activate', notify: true },  { id: 3, name: 'Utilities Hub', icon: 'Zap', bg: 'bg-amber-100', color: 'text-amber-600', desc: 'Pay bills, airtime & subscriptions', status: 'Active', variant: 'success', last: 'Yesterday, 18:30', action: 'Enter', notify: false },  { id: 4, name: 'Developer Portal', icon: 'Code', bg: 'bg-sky-100', color: 'text-sky-600', desc: 'API keys, webhooks & sandbox', status: 'Not Activated', variant: 'grey', last: '—', action: 'Activate', notify: false },  { id: 5, name: 'Loans & Credit', icon: 'Banknote', bg: 'bg-sky-100', color: 'text-sky-600', desc: 'Personal & business loans', status: 'Active', variant: 'success', last: '25 Jun, 09:12', action: 'Enter', notify: false },  { id: 6, name: 'Savings & Investments', icon: 'PiggyBank', bg: 'bg-purple-100', color: 'text-purple-600', desc: 'MMF, fixed deposits & SACCO', status: 'Active', variant: 'success', last: '24 Jun, 11:45', action: 'Enter', notify: false },  { id: 7, name: 'Crypto Center', icon: 'Bitcoin', bg: 'bg-red-100', color: 'text-red-600', desc: 'Buy, sell & hold digital assets', status: 'Suspended', variant: 'danger', last: '20 Jun, 08:00', action: 'Revoke', notify: true },  { id: 8, name: 'Cards Center', icon: 'CreditCard', bg: 'bg-sky-100', color: 'text-sky-600', desc: 'Virtual & physical cards', status: 'Active', variant: 'success', last: 'Today, 11:05', action: 'Enter', notify: false },  { id: 9, name: 'Insurance Hub', icon: 'ShieldPlus', bg: 'bg-emerald-100', color: 'text-emerald-600', desc: 'Motor, health & device cover', status: 'Not Activated', variant: 'grey', last: '—', action: 'Activate', notify: false },  { id: 10, name: 'Government Services', icon: 'Building2', bg: 'bg-amber-100', color: 'text-amber-600', desc: 'Rates, licences & eCitizen', status: 'Activation Pending', variant: 'warning', last: '—', action: 'Activate', notify: true }, ]; export const consentItems: ConsentItem[] = [  { name: 'Terms of Service', desc: 'General terms governing use of this PayMo dashboard.' },  { name: 'Acceptable Use Policy (AUP)', desc: 'What you can and cannot do with dashboard features.' },  { name: 'AML Compliance Declaration', desc: 'You confirm funds are from legitimate sources.' },  { name: 'CTF Acknowledgment', desc: 'You agree to flag suspicious transactions.' },  { name: 'Data Sharing Consent', desc: 'Allows cross-dashboard balance visibility for linked accounts.' },  { name: 'Cross-Dashboard Transaction Authorization', desc: 'Permits transfers between your linked dashboards.' },  { name: 'Regulatory Compliance Attestation', desc: 'CBK / KRA / sector-specific compliance confirmation.' },  { name: 'Fee Schedule & Pricing Acknowledgment', desc: 'You accept the published fees for this dashboard.' },  { name: 'Privacy Policy Addendum', desc: 'Dashboard-specific data processing addendum.' },  { name: 'Marketing & Promotional Consent', desc: 'Optional — not mandatory for activation.', optional: true }, ]; export const linkableAccounts: LinkableAccount[] = [  { id: 1, name: 'PayMo KES Wallet', origin: 'Transaction Hub', icon: 'Wallet', bg: 'bg-emerald-100', color: 'text-emerald-600', number: '•••• 5530', balance: 'KES 1,284,300', status: 'Linked', variant: 'success' },  { id: 2, name: 'Business Float', origin: 'Business Portal', icon: 'Briefcase', bg: 'bg-purple-100', color: 'text-purple-600', number: '•••• 2207', balance: 'KES 6,150,000', status: 'Linked', variant: 'success' },  { id: 3, name: 'Savings Jar', origin: 'Savings & Investments', icon: 'PiggyBank', bg: 'bg-amber-100', color: 'text-amber-600', number: '•••• 7793', balance: 'KES 480,000', status: 'Linked', variant: 'success' },  { id: 4, name: 'Loan Disbursement', origin: 'Loans & Credit', icon: 'Banknote', bg: 'bg-sky-100', color: 'text-sky-600', number: '•••• 8910', balance: 'KES 0', status: 'Link Revoked', variant: 'danger' },  { id: 5, name: 'Fiat On-ramp', origin: 'Crypto Center', icon: 'Bitcoin', bg: 'bg-red-100', color: 'text-red-600', number: '•••• 0042', balance: 'USD 2,410', status: 'Link Requested', variant: 'warning' },  { id: 6, name: 'Old Collection Float', origin: 'Business Portal', icon: 'FolderOpen', bg: 'bg-sky-100', color: 'text-sky-600', number: '•••• 3310', balance: 'KES 0', status: 'Unlinked', variant: 'grey' },  { id: 7, name: 'MMF Account', origin: 'Savings & Investments', icon: 'TrendingUp', bg: 'bg-emerald-100', color: 'text-emerald-600', number: '•••• 9091', balance: 'KES 2,100,000', status: 'Linked', variant: 'success' },  { id: 8, name: 'Credit Line Wallet', origin: 'Loans & Credit', icon: 'Landmark', bg: 'bg-purple-100', color: 'text-purple-600', number: '•••• 1187', balance: 'KES 750,000', status: 'Link Requested', variant: 'warning' },  { id: 9, name: 'Stablecoin Wallet', origin: 'Crypto Center', icon: 'Coins', bg: 'bg-amber-100', color: 'text-amber-600', number: '•••• 6642', balance: 'USDT 4,200', status: 'Unlinked', variant: 'grey' }, ]; export const activeLinks: ActiveLink[] = [  { id: 1, name: 'PayMo KES Wallet', origin: 'Transaction Hub', icon: 'Wallet', bg: 'bg-emerald-100', color: 'text-emerald-600', number: '•••• 5530', linked: '12 Jan 2023', balance: 'KES 1,284,300', status: 'Active', permission: 'Full Control', full: true, notifyMobile: true, notifyEmail: false, notifyPush: true },  { id: 2, name: 'Business Float', origin: 'Business Portal', icon: 'Briefcase', bg: 'bg-purple-100', color: 'text-purple-600', number: '•••• 2207', linked: '03 Feb 2024', balance: 'KES 6,150,000', status: 'Active', permission: 'Full Control', full: true, notifyMobile: true, notifyEmail: true, notifyPush: true },  { id: 3, name: 'Savings Jar', origin: 'Savings & Investments', icon: 'PiggyBank', bg: 'bg-amber-100', color: 'text-amber-600', number: '•••• 7793', linked: '15 Mar 2024', balance: 'KES 480,000', status: 'Active', permission: 'View + Transfer In', full: false, notifyMobile: false, notifyEmail: false, notifyPush: true },  { id: 4, name: 'Loan Disbursement', origin: 'Loans & Credit', icon: 'Banknote', bg: 'bg-sky-100', color: 'text-sky-600', number: '•••• 8910', linked: '02 Apr 2025', balance: 'KES 0', status: 'Paused', permission: 'View Only', full: false, notifyMobile: false, notifyEmail: false, notifyPush: false },  { id: 5, name: 'Fiat On-ramp', origin: 'Crypto Center', icon: 'Bitcoin', bg: 'bg-red-100', color: 'text-red-600', number: '•••• 0042', linked: '12 Jun 2025', balance: 'USD 2,410', status: 'Active', permission: 'View + Transfer In', full: false, notifyMobile: true, notifyEmail: false, notifyPush: true },  { id: 6, name: 'MMF Account', origin: 'Savings & Investments', icon: 'TrendingUp', bg: 'bg-emerald-100', color: 'text-emerald-600', number: '•••• 9091', linked: '20 Aug 2024', balance: 'KES 2,100,000', status: 'Active', permission: 'One-Way In', full: false, notifyMobile: false, notifyEmail: true, notifyPush: false }, ]; export const autoRules: AutoRule[] = [  { id: 1, name: 'Balance sweep', desc: 'IF Business Float > KES 3M THEN move 50% to KES Wallet', tag: 'Threshold', tagColor: 'bg-amber-100 text-amber-700', active: true },  { id: 2, name: 'Salary split', desc: 'On salary credit, auto-distribute 40% to Savings Jar', tag: 'Schedule', tagColor: 'bg-sky-100 text-sky-700', active: true },  { id: 3, name: 'Round-up', desc: 'Round transactions to nearest 100 KES → Savings', tag: 'Round-up', tagColor: 'bg-purple-100 text-purple-700', active: true },  { id: 4, name: 'Bill top-up', desc: 'On bill due, auto-pull KES 15,000 to Utilities', tag: 'Trigger', tagColor: 'bg-emerald-100 text-emerald-700', active: false }, ]; export const sessions: Session[] = [  { device: 'iPhone 15 Pro', detail: 'iOS 18.5 • App v4.2.1', location: 'Nairobi, KE', dash: '6 dashboards', lastActive: 'Just now', ip: '102.68.XX.XX', status: 'Current', current: true },  { device: 'MacBook Pro', detail: 'macOS 15.4 • Safari', location: 'Nairobi, KE', dash: '6 dashboards', lastActive: '14:22 today', ip: '102.68.XX.XX', status: 'Active', current: false },  { device: 'Windows PC', detail: 'Windows 11 • Chrome', location: 'Nairobi, KE', dash: '3 dashboards', lastActive: '26 Jun 2025', ip: '102.68.XX.XX', status: 'New', current: false },  { device: 'iPad Air', detail: 'iPadOS 18.4 • App', location: 'Mombasa, KE', dash: '2 dashboards', lastActive: '20 Jun 2025', ip: '105.XX.XX.XX', status: 'Active', current: false }, ]; export const accessLogs: AccessLog[] = [  { date: '27 Jun 2025 14:22', action: 'Dashboard activated (Business Portal)', dash: 'Business', ip: '102.68.XX.XX', device: 'iPhone 15 Pro', status: 'Success', variant: 'success' },  { date: '27 Jun 2025 14:21', action: 'Account linked (Business Float)', dash: 'Business', ip: '102.68.XX.XX', device: 'iPhone 15 Pro', status: 'Success', variant: 'success' },  { date: '26 Jun 2025 07:58', action: 'New device login (Windows PC)', dash: 'All', ip: '102.68.XX.XX', device: 'Windows PC', status: 'Review', variant: 'warning' },  { date: '20 Jun 2025 08:00', action: 'Crypto Center access revoked', dash: 'Crypto', ip: '105.XX.XX.XX', device: 'iPad Air', status: 'Revoked', variant: 'danger' },  { date: '15 Jun 2025 09:10', action: 'Permission changed (Savings Jar)', dash: 'Savings', ip: '102.68.XX.XX', device: 'MacBook Pro', status: 'Success', variant: 'success' }, ]; export const tourSteps = [  { title: 'Welcome to Business Portal', desc: 'This dashboard gives you merchant payment tools, payroll, collections, and business float management. Let’s walk through what you’ll find here.' },  { title: 'Business Float Account', desc: 'Your dedicated business wallet for receiving payments, managing payroll, and handling collections. Separate from your personal wallet.' },  { title: 'Merchant Payments', desc: 'Accept payments from customers via QR, paybill, or direct transfer. Track all incoming payments in real-time.' },  { title: 'Payroll & Disbursements', desc: 'Bulk salary payments, vendor disbursements, and scheduled payments. Support for CSV upload and recurring payouts.' },  { title: 'Collections & Invoicing', desc: 'Generate invoices, send payment reminders, and automatically reconcile incoming payments against outstanding invoices.' },  { title: 'Cross-Dashboard Linking', desc: 'Link your Transaction Hub wallet, Savings Jar, or other accounts to seamlessly move funds between dashboards.' },  { title: 'Reports & Analytics', desc: 'Business performance dashboards, revenue trends, expense breakdowns, and exportable financial reports.' },  { title: 'Security & Compliance', desc: 'Business-grade security with multi-signature approvals, audit trails, and regulatory compliance tools.' }, ]; export const relocationSteps = [  'Select Source Account',  'Select Destination Account',  'Enter Amount',  'Review Account Details',  'Confirm Recipient Identity',  'Security Verification (PIN)',  'Final Review & Confirmation',  'Processing & Receipt', ]; export type ModalId =  | 'walletDetail'  | 'walletFund'  | 'shareQR'  | 'downloadPDF'  | 'walletHealth'  | 'activateDashboard'  | 'linkAccount'  | 'accountPermissions'  | 'notificationSettings'  | 'moneyRelocation'  | 'revokeAccess'  | 'sessionManagement'  | 'accessLogs'  | 'autoRules'  | 'tourGuide'  | 'unlinkAccount'
  | 'dashboards';

import { create } from 'zustand';
import { type ModalId, type ActiveLink } from './paymo-data-store';

interface PayMoState {
  /* Modal management */
  modals: Record<ModalId, boolean>;
  openModal: (id: ModalId) => void;
  closeModal: (id: ModalId) => void;
  closeAllModals: () => void;

  /* Activation flow */
  selectedDashboard: string;
  setSelectedDashboard: (name: string) => void;
  consentAccepted: boolean[];
  toggleConsent: (index: number) => void;
  acceptAllConsent: () => void;
  pinEntered: string;
  setPinEntered: (pin: string) => void;
  isActivating: boolean;
  setIsActivating: (v: boolean) => void;
  activationComplete: boolean;
  setActivationComplete: (v: boolean) => void;

  /* Linked accounts */
  linkedAccounts: ActiveLink[];
  updateLinkPermission: (id: number, permission: string) => void;
  updateLinkNotify: (id: number, channel: 'notifyMobile' | 'notifyEmail' | 'notifyPush') => void;
  unlinkAccount: (id: number) => void;
  relinkAccount: (id: number) => void;
  unlinkTargetId: number | null;
  setUnlinkTargetId: (id: number | null) => void;

  /* Money relocation */
  relocationSource: string;
  setRelocationSource: (v: string) => void;
  relocationDest: string;
  setRelocationDest: (v: string) => void;
  relocationAmount: string;
  setRelocationAmount: (v: string) => void;
  relocationStep: number;
  setRelocationStep: (s: number) => void;

  /* Auto rules */
  rulesEnabled: Record<number, boolean>;
  toggleRule: (id: number) => void;
}

const initialModals: Record<ModalId, boolean> = {
  walletDetail: false,
  walletFund: false,
  shareQR: false,
  downloadPDF: false,
  walletHealth: false,
  activateDashboard: false,
  linkAccount: false,
  accountPermissions: false,
  notificationSettings: false,
  moneyRelocation: false,
  revokeAccess: false,
  sessionManagement: false,
  accessLogs: false,
  autoRules: false,
  tourGuide: false,
  unlinkAccount: false,
  dashboards: false,
};

const initialLinkedAccounts: ActiveLink[] = [
  { id: 1, name: 'PayMo KES Wallet', origin: 'Transaction Hub', icon: 'Wallet', bg: 'bg-emerald-100', color: 'text-emerald-600', number: '**** 5530', linked: '12 Jan 2023', balance: 'KES 1,284,300', status: 'Active', permission: 'Full Control', full: true, notifyMobile: true, notifyEmail: false, notifyPush: true },
  { id: 2, name: 'Business Float', origin: 'Business Portal', icon: 'Briefcase', bg: 'bg-purple-100', color: 'text-purple-600', number: '**** 2207', linked: '03 Feb 2024', balance: 'KES 6,150,000', status: 'Active', permission: 'Full Control', full: true, notifyMobile: true, notifyEmail: true, notifyPush: true },
  { id: 3, name: 'Savings Jar', origin: 'Savings & Investments', icon: 'PiggyBank', bg: 'bg-amber-100', color: 'text-amber-600', number: '**** 7793', linked: '15 Mar 2024', balance: 'KES 480,000', status: 'Active', permission: 'View + Transfer In', full: false, notifyMobile: false, notifyEmail: false, notifyPush: true },
  { id: 4, name: 'Loan Disbursement', origin: 'Loans & Credit', icon: 'Banknote', bg: 'bg-sky-100', color: 'text-sky-600', number: '**** 8910', linked: '02 Apr 2025', balance: 'KES 0', status: 'Paused', permission: 'View Only', full: false, notifyMobile: false, notifyEmail: false, notifyPush: false },
  { id: 5, name: 'Fiat On-ramp', origin: 'Crypto Center', icon: 'Bitcoin', bg: 'bg-red-100', color: 'text-red-600', number: '**** 0042', linked: '12 Jun 2025', balance: 'USD 2,410', status: 'Active', permission: 'View + Transfer In', full: false, notifyMobile: true, notifyEmail: false, notifyPush: true },
  { id: 6, name: 'MMF Account', origin: 'Savings & Investments', icon: 'TrendingUp', bg: 'bg-emerald-100', color: 'text-emerald-600', number: '**** 9091', linked: '20 Aug 2024', balance: 'KES 2,100,000', status: 'Active', permission: 'One-Way In', full: false, notifyMobile: false, notifyEmail: true, notifyPush: false },
];

export const usePayMoStore = create<PayMoState>((set) => ({
  modals: { ...initialModals },
  openModal: (id) => set((s) => ({ modals: { ...s.modals, [id]: true } })),
  closeModal: (id) => set((s) => ({ modals: { ...s.modals, [id]: false } })),
  closeAllModals: () => set({ modals: { ...initialModals } }),

  selectedDashboard: 'Business Portal',
  setSelectedDashboard: (name) => set({ selectedDashboard: name, consentAccepted: new Array(10).fill(false), pinEntered: '', activationComplete: false }),
  consentAccepted: new Array(10).fill(false),
  toggleConsent: (index) => set((s) => {
    const next = [...s.consentAccepted];
    next[index] = !next[index];
    return { consentAccepted: next };
  }),
  acceptAllConsent: () => set({ consentAccepted: new Array(10).fill(true) }),
  pinEntered: '',
  setPinEntered: (pin) => set({ pinEntered: pin }),
  isActivating: false,
  setIsActivating: (v) => set({ isActivating: v }),
  activationComplete: false,
  setActivationComplete: (v) => set({ activationComplete: v }),

  linkedAccounts: [...initialLinkedAccounts],
  updateLinkPermission: (id, permission) => set((s) => ({
    linkedAccounts: s.linkedAccounts.map((a) => a.id === id ? { ...a, permission, full: permission === 'Full Control' } : a),
  })),
  updateLinkNotify: (id, channel) => set((s) => ({
    linkedAccounts: s.linkedAccounts.map((a) => a.id === id ? { ...a, [channel]: !a[channel] } : a),
  })),
  unlinkAccount: (id) => set((s) => ({
    linkedAccounts: s.linkedAccounts.filter((a) => a.id !== id),
  })),
  relinkAccount: (id) => set((s) => ({
    linkedAccounts: s.linkedAccounts.map((a) => a.id === id ? { ...a, status: 'Active' as const } : a),
  })),
  unlinkTargetId: null,
  setUnlinkTargetId: (id) => set({ unlinkTargetId: id }),

  relocationSource: '',
  setRelocationSource: (v) => set({ relocationSource: v }),
  relocationDest: '',
  setRelocationDest: (v) => set({ relocationDest: v }),
  relocationAmount: '',
  setRelocationAmount: (v) => set({ relocationAmount: v }),
  relocationStep: 0,
  setRelocationStep: (s) => set({ relocationStep: s }),

  rulesEnabled: { 1: true, 2: true, 3: true, 4: false },
  toggleRule: (id) => set((s) => ({ rulesEnabled: { ...s.rulesEnabled, [id]: !s.rulesEnabled[id] } })),
}));
